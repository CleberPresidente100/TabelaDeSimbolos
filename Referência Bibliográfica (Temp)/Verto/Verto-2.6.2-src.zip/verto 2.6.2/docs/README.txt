* License

Verto is free software, and you are welcome to redistribute and modify
it under the terms of the GNU General Public License (either version 2
or any later version). See the file COPYING.txt for details.
