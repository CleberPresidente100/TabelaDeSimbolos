package verto.ui;


import java.awt.Color;
import java.io.File;

public class Cor {
	
	public static final int HEADER_WINDOWS_PAR				 = 1;
	public static final int HEADER_METAL_PAR				 = 2;
	public static final int HEADER_MOTIF_PAR				 = 3;
	public static final int BROWSE_WINDOWS_PAR				 = 4;
	public static final int BROWSE_METAL_PAR				 = 5;
	public static final int BROWSE_MOTIF_PAR				 = 6;
	public static final int BROWSE_WINDOWS_IMPAR			 = 7;
	public static final int BROWSE_METAL_IMPAR				 = 8;
	public static final int BROWSE_MOTIF_IMPAR				 = 9;
	public static final int BROWSE_SEL_WINDOWS_PAR			 = 10;
	public static final int BROWSE_SEL_METAL_PAR			 = 11;
	public static final int BROWSE_SEL_MOTIF_PAR			 = 12;
	public static final int BROWSE_SEL_WINDOWS_IMPAR		 = 13;
	public static final int BROWSE_SEL_METAL_IMPAR			 = 14;
	public static final int BROWSE_SEL_MOTIF_IMPAR			 = 15;
	
	public static final int TEXTFIELD_SELECTION_BACKGROUND	 = 51;
	public static final int TEXTFIELD_SELECTION_FOREGROUND	 = 52;
	public static final int TEXTAREA_BACKGROUND	 			 = 53;
	public static final int TEXTAREA_FOREGROUND	 			 = 54;
	
	public static Color headerWindowsPar;
	public static Color headerMetalPar;	
	public static Color headerMotifPar;
	public static Color browseWindowsPar;
	public static Color browseMetalPar;	
	public static Color browseMotifPar;
	public static Color browseWindowsImpar;
	public static Color browseMetalImpar;	
	public static Color browseMotifImpar;
	public static Color browselWindowsPar;
	public static Color browselMetalPar;	
	public static Color browselMotifPar;
	public static Color browselWindowsImpar;
	public static Color browselMetalImpar;	
	public static Color browselMotifImpar;

	public static Color textFieldSelectionForeground;
	public static Color textFieldSelectionBackground;
	public static Color textAreaForeground;
	public static Color textAreaBackground;

	public static void carregaCores() {
		
		File diretorioHome = new File(System.getProperty("user.home"));
		String trilha = diretorioHome.getAbsolutePath() + File.separatorChar + "vertoParametros.txt";

		carregaCores( trilha );
	}

	public static void carregaCores( String caminho ) {
	
		headerWindowsPar = Cores.buscaCor( Cores.HEADER_WINDOWS_PAR, caminho );
		headerMetalPar = Cores.buscaCor( Cores.HEADER_METAL_PAR, caminho );
		headerMotifPar = Cores.buscaCor( Cores.HEADER_MOTIF_PAR, caminho );
		browseWindowsPar = Cores.buscaCor( Cores.BROWSE_WINDOWS_PAR, caminho );
		browseMetalPar = Cores.buscaCor( Cores.BROWSE_METAL_PAR, caminho );
		browseMotifPar = Cores.buscaCor( Cores.BROWSE_MOTIF_PAR, caminho );
		browseWindowsImpar = Cores.buscaCor( Cores.BROWSE_WINDOWS_IMPAR, caminho );
		browseMetalImpar = Cores.buscaCor( Cores.BROWSE_METAL_IMPAR, caminho );
		browseMotifImpar = Cores.buscaCor( Cores.BROWSE_MOTIF_IMPAR, caminho );
		browselWindowsPar = Cores.buscaCor( Cores.BROWSE_SEL_WINDOWS_PAR, caminho );
		browselMetalPar = Cores.buscaCor( Cores.BROWSE_SEL_METAL_PAR, caminho );
		browselMotifPar = Cores.buscaCor( Cores.BROWSE_SEL_MOTIF_PAR, caminho );
		browselWindowsImpar = Cores.buscaCor( Cores.BROWSE_SEL_WINDOWS_IMPAR, caminho );
		browselMetalImpar = Cores.buscaCor( Cores.BROWSE_SEL_METAL_IMPAR, caminho );
		browselMotifImpar = Cores.buscaCor( Cores.BROWSE_SEL_MOTIF_IMPAR, caminho );

		textFieldSelectionForeground = Cores.buscaCor( Cores.TEXTFIELD_SELECTION_FOREGROUND, caminho );
		textFieldSelectionBackground = Cores.buscaCor( Cores.TEXTFIELD_SELECTION_BACKGROUND, caminho );
		textAreaForeground = Cores.buscaCor( Cores.TEXTAREA_FOREGROUND, caminho );
		textAreaBackground = Cores.buscaCor( Cores.TEXTAREA_BACKGROUND, caminho );
	}
	
}