package verto.ui;
/*
 * $Id: AparenciaListener.java,v 1.2 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 */

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;

import verto.Verto;
import verto.exception.ErroDeCompilacaoException;

/**
 * Classe Aparencia Listener
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Verto
 * @see ErroDeCompilacaoException
 * 
 * @version 2.6.2
 */
public class AparenciaListener implements ActionListener {
  Frame frame;
  
  public static final int ESTILO_MOTIF               = 0;
  public static final int ESTILO_METAL               = 1;
  public static final int ESTILO_WINDOWS 			  = 2;
  public static final int ESTILO_WINDOWS_CLASSIC	  = 3;
  public static final int ESTILO_GTK 	              = 4;
  public static final int ESTILO_MAC 	              = 5;
  public static final int ESTILO_NIMBUS	              = 6;
  
  private JCheckBoxMenuItem mnMotif;
  private JCheckBoxMenuItem mnMetal;
  private JCheckBoxMenuItem mnWindows;
  private JCheckBoxMenuItem mnWindowsClassic;
  private JCheckBoxMenuItem mnGTK;
  private JCheckBoxMenuItem mnMac;
  private JCheckBoxMenuItem mnNimbus;

  public AparenciaListener(Frame f) {
    frame = f;
  }

  public void actionPerformed(ActionEvent e) {
  	
	    if (e.getActionCommand().equals("Metal")) {
	    	selecionaMetal();
	    } else if (e.getActionCommand().equals("Motif")) {
	    	selecionaMotif();
	    } else if (e.getActionCommand().equals("Windows")) {
	    	selecionaWindows();
	    } else if (e.getActionCommand().equals("WindowsClassic")) {
	    	selecionaWindowsClassic();
	    } else if (e.getActionCommand().equals("GTK")) {
	    	selecionaGTK();
	    } else if (e.getActionCommand().equals("Mac")) {
	    	selecionaMac();
	    } else if (e.getActionCommand().equals("Nimbus")) {
	    	selecionaNimbus();
	    } else {
	    	System.err.println( "Look and Feel n�o identificado: " + e.getActionCommand() ); 
	    	return;
	    }
  }
  
  private void selecionaMetal() {
	  	
	    mnMotif.setSelected( false );
	    mnMetal.setSelected( true );
	    mnWindows.setSelected( false );
	    mnWindowsClassic.setSelected( false );
	    mnGTK.setSelected( false );
	    mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
	  	selecionaLookAndFeel( "javax.swing.plaf.metal.MetalLookAndFeel" );
  }

  private void selecionaMotif() {

	  	mnMetal.setSelected( false );
	  	mnMotif.setSelected( true );
	    mnWindows.setSelected( false );
	    mnWindowsClassic.setSelected( false );
	    mnGTK.setSelected( false );
	    mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
	  	selecionaLookAndFeel( "com.sun.java.swing.plaf.motif.MotifLookAndFeel" );
  }
	  
  private void selecionaWindows() {

	    mnMotif.setSelected( false );
	    mnMetal.setSelected( false );
	    mnWindows.setSelected( true );
	    mnWindowsClassic.setSelected( false );
	    mnGTK.setSelected( false );
	    mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
	  	selecionaLookAndFeel( "com.sun.java.swing.plaf.windows.WindowsLookAndFeel" );
  }

  private void selecionaWindowsClassic() {

		mnMotif.setSelected( false );
		mnMetal.setSelected( false );
		mnWindows.setSelected( false ); 
		mnWindowsClassic.setSelected( true );
		mnGTK.setSelected( false );
		mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
		selecionaLookAndFeel( "com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel" );
  }

  private void selecionaGTK() {

		mnMotif.setSelected( false );
		mnMetal.setSelected( false );
		mnWindows.setSelected( false ); 
	    mnWindowsClassic.setSelected( false );
		mnGTK.setSelected( true );
	    mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
		selecionaLookAndFeel( "com.sun.java.swing.plaf.gtk.GTKLookAndFeel" );
  }

  private void selecionaMac() {

		mnMotif.setSelected( false );
		mnMetal.setSelected( false );
		mnWindows.setSelected( false ); 
		mnWindowsClassic.setSelected( false );
		mnGTK.setSelected( true );
		mnMac.setSelected( false );
	    mnNimbus.setSelected( false );
		selecionaLookAndFeel( "javax.swing.plaf.mac.MacLookAndFeel" );
  }
  
  private void selecionaNimbus() {

		mnMotif.setSelected( false );
		mnMetal.setSelected( false );
		mnWindows.setSelected( false ); 
		mnWindowsClassic.setSelected( false );
		mnGTK.setSelected( false );
		mnMac.setSelected( false );
	    mnNimbus.setSelected( true );
		selecionaLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel" );
}
  
  private void selecionaLookAndFeel( String vlstnLookAndFeel ) {

    try {
        UIManager.setLookAndFeel( vlstnLookAndFeel );
        SwingUtilities.updateComponentTreeUI(frame);
      } catch (UnsupportedLookAndFeelException ex1) {
        System.err.println("LookAndFeel n�o suportado: " + vlstnLookAndFeel);
      } catch (ClassNotFoundException ex2) {
        System.err.println("Classe LookAndFeel n�o encontrada: " + vlstnLookAndFeel);
      } catch (InstantiationException ex3) {
        System.err.println("LookAndFeel n�o pode ser carregado: " + vlstnLookAndFeel);
      } catch (IllegalAccessException ex4) {
        System.err.println("LookAndFeel n�o pode ser usado: " + vlstnLookAndFeel);
      }
  }

  public void alternaEstilo() {
	  	
	  	if( mnMetal.isSelected() ) {
	  		selecionaWindows();
	  	} else if( mnMotif.isSelected() ) {
	  		selecionaMetal();
	  	} else if( mnWindows.isSelected() ) {
	  		selecionaWindowsClassic();
	  	} else if( mnWindowsClassic.isSelected() ) {
	  		selecionaGTK();
	  	} else if( mnGTK.isSelected() ) {
	  		selecionaMac();
	  	} else if( mnMac.isSelected() ) {
	  		selecionaNimbus();
	  	} else if( mnNimbus.isSelected() ) {
	  		selecionaMotif();
	  	}
  }

  public void setEstilo() {
	  setEstilo(false);
  }
  
  public void setEstilo(boolean inicio) {
	if(inicio){
		for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			if ("Nimbus".equals(info.getName())) {
				selecionaNimbus();
				break;
			}
		}
		
	}else{
		if( mnMetal.isSelected() ) {
			selecionaMetal();
		} else if( mnMotif.isSelected() ) {
			selecionaMotif();
		} else if( mnWindows.isSelected() ) {
			selecionaWindows();
		} else if( mnWindowsClassic.isSelected() ) {
			selecionaWindowsClassic();
		} else if( mnGTK.isSelected() ) {
			selecionaGTK();
		} else if( mnMac.isSelected() ) {
			selecionaMac();
		} else if( mnNimbus.isSelected() ) {
			selecionaNimbus();
		} else {
			selecionaMetal();
		}
	}  
  }
  
  public void setEstilo( int estilo ) {
	  	
	  	if( estilo == ESTILO_METAL ) {
	  		selecionaMetal();
	  	} else if( estilo == ESTILO_MOTIF ) {
	  		selecionaMotif();
	  	} else if( estilo == ESTILO_WINDOWS ) {
	  		selecionaWindows();
	  	} else if( estilo == ESTILO_WINDOWS_CLASSIC ) {
	  		selecionaWindowsClassic();
	  	} else if( estilo == ESTILO_GTK ) {
	  		selecionaGTK();
	  	} else if( estilo == ESTILO_MAC ) {
	  		selecionaMac();
	  	} else if( estilo == ESTILO_NIMBUS ) {
	  		selecionaNimbus();
	  	} else {
	  		selecionaMetal();
	  	}
  }

  public int getEstilo() {
	  	
	  	if( isMetal() ) {
	  		return ESTILO_METAL;
	  	} else if( isMotif() ) {
	  		return ESTILO_MOTIF;
	  	} else if( isWindows() ) {
	  		return ESTILO_WINDOWS;
	  	} else if( isWindowsClassic() ) {
	  		return ESTILO_WINDOWS_CLASSIC;
	  	} else if( isGTK() ) {
	  		return ESTILO_GTK;
	  	} else if( isMac() ) {
	  		return ESTILO_MAC;
	  	} else if( isNimbus() ) {
	  		return ESTILO_NIMBUS;
	  	} else {
	  		return ESTILO_METAL;
	  	}
}
 
  public String getNomeEstilo() {

	  if( isMetal() ) {
	  		return "Metal";
	  	} else if( isMotif() ) {
	  		return "Motif";
	  	} else if( isWindows() ) {
	  		return "Windows";
	  	} else if( isWindowsClassic() ) {
	  		return "WindowsClassic";
	  	} else if( isGTK() ) {
	  		return "GTK";
	  	} else if( isMac() ) {
	  		return "Mac";
	  	} else if( isNimbus() ) {
	  		return "Nimbus";
	  	} else {
	  		return "Metal";
	  	}
  }  
  
  public void setNomeEstilo( String estilo ) {
	  	
	    if (estilo.equalsIgnoreCase("Metal")) {
	    	selecionaMetal();
	    } else if (estilo.equalsIgnoreCase("Motif")) {
	    	selecionaMotif();
	    } else if (estilo.equalsIgnoreCase("Windows")) {
	    	selecionaWindows();
	    } else if (estilo.equalsIgnoreCase("WindowsClassic")) {
	    	selecionaWindowsClassic();
	    } else if (estilo.equalsIgnoreCase("GTK")) {
	    	selecionaGTK();
	    } else if (estilo.equalsIgnoreCase("Mac")) {
	    	selecionaMac();
	    } else if (estilo.equalsIgnoreCase("Nimbus")) {
	    	selecionaNimbus();
	    } else {
	    	System.err.println( "Look and Feel n�o identificado: " + estilo ); 
	    	return;
	    }
}
  
  public boolean isMetal() {
  	return mnMetal.isSelected();
  }
	  
  public boolean isMotif() {
  	return mnMotif.isSelected();
  }
	  
  public boolean isWindows() {
  	return mnWindows.isSelected();
  }
	  
  public boolean isWindowsClassic() {
	return mnWindows.isSelected();
  }
		  
  public boolean isGTK() {
	return mnGTK.isSelected();
  }
		  
  public boolean isMac() {
	return mnMac.isSelected();
  }

  public boolean isNimbus() {
	return mnNimbus.isSelected();
  }
  
  public void setMnMetal(JCheckBoxMenuItem mnMetal) {
  	this.mnMetal = mnMetal;
  }

  public void setMnMotif(JCheckBoxMenuItem mnMotif) {
  	this.mnMotif = mnMotif;
  }

  public void setMnWindows(JCheckBoxMenuItem mnWindows) {
  	this.mnWindows = mnWindows;
  }

  public void setMnWindowsClassic(JCheckBoxMenuItem mnWindowsClassic) {
	this.mnWindowsClassic = mnWindowsClassic;
  }
	  
  public void setMnGTK(JCheckBoxMenuItem mnGTK) {
	this.mnGTK = mnGTK;
  }

  public void setMnMac(JCheckBoxMenuItem mnMac) {
	this.mnMac = mnMac;
  }

  public void setMnNimbus(JCheckBoxMenuItem mnNimbus) {
		this.mnNimbus = mnNimbus;
  }
  
}
