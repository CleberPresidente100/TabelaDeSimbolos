package verto.ui;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * Classe FiltroTema: Classe para Implementar um Filtro para extens�o: *.tma
 * 
 * @author Carlos S�rgio Schneider
 * @author Ricardo Ferreira de Oliveira
 * 
 * @version 2.6.2
 */
public class FiltroTema extends FileFilter {

	public boolean accept(File arg0) {
	   	 if(arg0 != null) {
	         if(arg0.isDirectory()) {
	       	  return true;
	         }
	         if( getExtensao(arg0) != null) {
	        	 if ( getExtensao(arg0).equalsIgnoreCase( "tma" ) ) {
		        	 return true;
	        	 }
	         };
	   	 }
	     return false;
	}

	/**
	 * Retorna quais extens�es poder�o ser escolhidas
	 */
	public String getDescription() {
		return "*.tma";
	}
	
	/**
	 * Retorna a parte com a extens�o de um arquivo
	 */
	public String getExtensao(File arq) {
	if(arq != null) {
		String filename = arq.getName();
	    int i = filename.lastIndexOf('.');
	    if(i>0 && i<filename.length()-1) {
	    	return filename.substring(i+1).toLowerCase();
	    };
	}
		return null;
	}
	
}