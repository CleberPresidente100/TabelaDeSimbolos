package verto.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

import verto.Verto;


/**
 * Classe: Cores
 * 
 * @author Carlos S�rgio Schneider 
 * @author Ricardo Ferreira de Oliveira
 *  
 * @version 2.6.2
 */
public class Cores extends JDialog implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int INATIVO 						 = 0;
	public static final int CONSULTANDO						 = 1;
	public static final int INCLUINDO						 = 2;
	public static final int ALTERANDO						 = 3;
	public static final int EXCLUINDO						 = 4;
	
	public static final int HEADER_WINDOWS_PAR				 = 1;
	public static final int HEADER_METAL_PAR				 = 2;
	public static final int HEADER_MOTIF_PAR				 = 3;
	public static final int BROWSE_WINDOWS_PAR				 = 4;
	public static final int BROWSE_METAL_PAR				 = 5;
	public static final int BROWSE_MOTIF_PAR				 = 6;
	public static final int BROWSE_WINDOWS_IMPAR			 = 7;
	public static final int BROWSE_METAL_IMPAR				 = 8;
	public static final int BROWSE_MOTIF_IMPAR				 = 9;
	public static final int BROWSE_SEL_WINDOWS_PAR			 = 10;
	public static final int BROWSE_SEL_METAL_PAR			 = 11;
	public static final int BROWSE_SEL_MOTIF_PAR			 = 12;
	public static final int BROWSE_SEL_WINDOWS_IMPAR		 = 13;
	public static final int BROWSE_SEL_METAL_IMPAR			 = 14;
	public static final int BROWSE_SEL_MOTIF_IMPAR			 = 15;

	public static final int TEXTFIELD_SELECTION_BACKGROUND	 = 51;
	public static final int TEXTFIELD_SELECTION_FOREGROUND	 = 52;
	public static final int TEXTAREA_BACKGROUND	 			 = 53;
	public static final int TEXTAREA_FOREGROUND	 			 = 54;
	
	public static final Color corHeaderWindowsPar			 = new Color(165, 183, 160); 
	public static final Color corHeaderMetalPar			     = new Color(124, 198, 255); 
	public static final Color corHeaderMotifPar			     = new Color(135, 124, 134); 
	
	public static final Color corBrowseWindowsPar			 = new Color(228, 253, 220); 
	public static final Color corBrowseMetalPar			     = new Color(238, 244, 247); 
	public static final Color corBrowseMotifPar			     = new Color(231, 231, 207); 
	public static final Color corBrowseWindowsImpar			 = new Color(198, 223, 190); 
	public static final Color corBrowseMetalImpar		     = new Color(196, 217, 225); 
	public static final Color corBrowseMotifImpar		     = new Color(220, 220, 220); 

	public static final Color corBrowselWindowsPar			 = new Color(168, 193, 178); 
	public static final Color corBrowselMetalPar			 = new Color(167, 208, 255); 
	public static final Color corBrowselMotifPar			 = new Color(200, 200, 170); 
	public static final Color corBrowselWindowsImpar		 = new Color(168, 193, 178); 
	public static final Color corBrowselMetalImpar		     = new Color(167, 208, 255); 
	public static final Color corBrowselMotifImpar		     = new Color(200, 200, 170); 

	public static final Color corTextFieldSelectionForeground = new Color(51, 51, 51); 
	public static final Color corTextFieldSelectionBackground = new Color(184, 207, 229); 
	public static final Color corTextAreaForeground           = new Color(51, 51, 51);
	public static final Color corTextAreaBackground			  = new Color(238, 238, 238);
	
	private static Cores mySelf;
	
	private int estadoCor;
	
	final 	Component 	c = this;
	private File 		fileName;
	
	private JButton btnAlterar;
	private JButton btnRestaurar;
	private JButton btnConfirmar;
	private JButton btnCancelar;
	private JButton btnSalvar;
	private JButton btnAbrir;

	private JTextField edtHeaderWindowsPar;
	private JTextField lblHeaderWindowsPar;
	private JButton    btnHeaderWindowsPar;

	private JTextField edtHeaderMetalPar;
	private JTextField lblHeaderMetalPar;
	private JButton    btnHeaderMetalPar;
	
	private JTextField edtHeaderMotifPar;
	private JTextField lblHeaderMotifPar;
	private JButton    btnHeaderMotifPar;
	
	private JTextField edtBrowseWindowsPar;
	private JTextField lblBrowseWindowsPar;
	private JButton    btnBrowseWindowsPar;

	private JTextField edtBrowseMetalPar;
	private JTextField lblBrowseMetalPar;
	private JButton    btnBrowseMetalPar;
	
	private JTextField edtBrowseMotifPar;
	private JTextField lblBrowseMotifPar;
	private JButton    btnBrowseMotifPar;

	private JTextField edtBrowseWindowsImpar;
	private JTextField lblBrowseWindowsImpar;
	private JButton    btnBrowseWindowsImpar;

	private JTextField edtBrowseMetalImpar;
	private JTextField lblBrowseMetalImpar;
	private JButton    btnBrowseMetalImpar;
	
	private JTextField edtBrowseMotifImpar;
	private JTextField lblBrowseMotifImpar;
	private JButton    btnBrowseMotifImpar;	

	private JTextField edtBrowselWindowsPar;
	private JTextField lblBrowselWindowsPar;
	private JButton    btnBrowselWindowsPar;

	private JTextField edtBrowselMetalPar;
	private JTextField lblBrowselMetalPar;
	private JButton    btnBrowselMetalPar;
	
	private JTextField edtBrowselMotifPar;
	private JTextField lblBrowselMotifPar;
	private JButton    btnBrowselMotifPar;

	private JTextField edtBrowselWindowsImpar;
	private JTextField lblBrowselWindowsImpar;
	private JButton    btnBrowselWindowsImpar;

	private JTextField edtBrowselMetalImpar;
	private JTextField lblBrowselMetalImpar;
	private JButton    btnBrowselMetalImpar;
	
	private JTextField edtBrowselMotifImpar;
	private JTextField lblBrowselMotifImpar;
	private JButton    btnBrowselMotifImpar;		

	// Segunda Aba
	
	private JTextField edtTextFieldSelectionBackground;
	private JTextField lblTextFieldSelectionBackground;
	private JButton    btnTextFieldSelectionBackground;	
	
	private JTextField edtTextFieldSelectionForeground;
	private JTextField lblTextFieldSelectionForeground;
	private JButton    btnTextFieldSelectionForeground;		
	
	private JTextField edtTextAreaBackground;
	private JTextField lblTextAreaBackground;
	private JButton    btnTextAreaBackground;	
	
	private JTextField edtTextAreaForeground;
	private JTextField lblTextAreaForeground;
	private JButton    btnTextAreaForeground;	

	private Properties queries = null;
	private String trilha = null;
	
	public static Properties propriedades = null;
    public static String caminho = null;
    public static File arquivo = null;
	
	private Verto programaPrincipal;
	
	public Cores( Verto pg ) {

		super( pg, "Cores", true );

		File diretorioHome = new File(System.getProperty("user.home"));
		trilha = diretorioHome.getAbsolutePath() + File.separatorChar + "vertoParametros.txt";
		
		estadoCor = CONSULTANDO;
		programaPrincipal = pg;
		
		mySelf = this;

		Container container = getContentPane();
		container.setLayout( new BorderLayout() );
		
		container.add( getPainelCentral(), BorderLayout.CENTER );
		container.add( getPainelSul(), BorderLayout.SOUTH );
		
		setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );	
		setDefaultLookAndFeelDecorated( true );
		
		container.setBackground( new Color ( 235, 245, 255 ) ); 
		
		this.setLocation( 100, 50 );
		setSize(700,500); 
		setVisible(true); 
	}

	private JComponent getPainelSul() {
		
		JPanel painelSul = new JPanel( null );

		// Bot�o para Alterar novo Caminho
	    btnAlterar = new JButton();
	    btnAlterar.setBounds( 220, 55, 25, 25 );
	    btnAlterar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/alteraTema.png" ) ) );
	    btnAlterar.setToolTipText( "Alterar" );
	    btnAlterar.setActionCommand( "Alterar" );
	    btnAlterar.addActionListener( this );
		painelSul.add( btnAlterar );
		
		// Bot�o para Incluir novo Caminho
	    btnRestaurar = new JButton();
	    btnRestaurar.setBounds( 250, 55, 25, 25 );
	    btnRestaurar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/restauraTema.png" ) ) );
	    btnRestaurar.setToolTipText( "Restaurar aos padr�es Originais" );
	    btnRestaurar.setActionCommand( "Restaurar" );
	    btnRestaurar.addActionListener( this );
		painelSul.add( btnRestaurar );		

		// Bot�o para Confirmar
	    btnConfirmar = new JButton();
	    btnConfirmar.setBounds( 280, 55, 25, 25 );
	    btnConfirmar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/confirmar.png" ) ) );
	    btnConfirmar.setToolTipText( "Confirma" );
	    btnConfirmar.setActionCommand( "Confirmar" );
	    btnConfirmar.addActionListener( this );
		painelSul.add( btnConfirmar );		

		// Bot�o para Cancelar
	    btnCancelar = new JButton();
	    btnCancelar.setBounds( 310, 55, 25, 25 );
	    btnCancelar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cancelar.png" ) ) );
	    btnCancelar.setToolTipText( "Cancela" );
	    btnCancelar.setActionCommand( "Cancelar" );
	    btnCancelar.addActionListener( this );
		painelSul.add( btnCancelar );		

		// Bot�o para Carregar Tema
	    btnAbrir = new JButton();
	    btnAbrir.setBounds( 380, 55, 25, 25 );
	    btnAbrir.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/carregarTema.png" ) ) );
	    btnAbrir.setToolTipText( "Carregar Tema" );
	    btnAbrir.setActionCommand( "Carregar" );
	    btnAbrir.addActionListener( this );
		painelSul.add( btnAbrir );		

		// Bot�o para Salvar Tema
	    btnSalvar = new JButton();
	    btnSalvar.setBounds( 410, 55, 25, 25 );
	    btnSalvar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/salvarTema.png" ) ) );
	    btnSalvar.setToolTipText( "Salvar Tema" );
	    btnSalvar.setActionCommand( "Salvar" );
	    btnSalvar.addActionListener( this );
		painelSul.add( btnSalvar );		
		
		habilitaBotoes();

		painelSul.setPreferredSize( new Dimension( 90, 90 ) );
		return painelSul;	
	}


	private Component getPainelCentral() {

		JTabbedPane painelzaoCentro = new JTabbedPane();
		
		JPanel painelBrowse = new JPanel( null );

		JLabel lblColuna1 = new JLabel( "Aparencia Metal" );
		lblColuna1.setForeground( Color.BLUE );
		lblColuna1.setBounds( 200, 5, 150, 20 );
		painelBrowse.add( lblColuna1 );

		JLabel lblColuna2 = new JLabel( "Aparencia Windows" );
		lblColuna2.setForeground( Color.BLUE );
		lblColuna2.setBounds( 360, 5, 150, 20 );
		painelBrowse.add( lblColuna2 );
		
		JLabel lblColuna3 = new JLabel( "Outras Aparencias" );
		lblColuna3.setForeground( Color.BLUE );
		lblColuna3.setBounds( 520, 5, 150, 20 );
		painelBrowse.add( lblColuna3 );
		
		// Cabecalho
		
		JLabel lblCabecalho = new JLabel( "Cabe�alho" );
		lblCabecalho.setBounds( 20, 30, 200, 20 );
		painelBrowse.add( lblCabecalho );
		
	    edtHeaderMetalPar = new JTextField();
	    edtHeaderMetalPar.setBounds( 200, 30, 70, 20 );
	    edtHeaderMetalPar.setEditable( false );
	    painelBrowse.add( edtHeaderMetalPar );
	    lblHeaderMetalPar = new JTextField();
	    lblHeaderMetalPar.setBounds( 275, 30, 30, 20 ); 
	    lblHeaderMetalPar.setEditable( false );
	    painelBrowse.add( lblHeaderMetalPar );
	    
	    btnHeaderMetalPar = new JButton();
	    btnHeaderMetalPar.setBounds( 310, 30, 20, 20 );
	    btnHeaderMetalPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnHeaderMetalPar.addActionListener( this );
	    btnHeaderMetalPar.setActionCommand( "EscolheCor" );
	    btnHeaderMetalPar.setName( "btnHeaderMetalPar" );
	    painelBrowse.add( btnHeaderMetalPar );
	    
		edtHeaderWindowsPar = new JTextField();
		edtHeaderWindowsPar.setBounds( 360, 30, 70, 20 );
		edtHeaderWindowsPar.setEditable( false );
	    painelBrowse.add( edtHeaderWindowsPar );
	    lblHeaderWindowsPar = new JTextField();
	    lblHeaderWindowsPar.setBounds( 435, 30, 30, 20 ); 
	    lblHeaderWindowsPar.setEditable( false );
	    painelBrowse.add( lblHeaderWindowsPar );
	    
	    btnHeaderWindowsPar = new JButton();
	    btnHeaderWindowsPar.setBounds( 470, 30, 20, 20 );
	    btnHeaderWindowsPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnHeaderWindowsPar.addActionListener( this );
	    btnHeaderWindowsPar.setActionCommand( "EscolheCor" );
	    btnHeaderWindowsPar.setName( "btnHeaderWindowsPar" );
	    painelBrowse.add( btnHeaderWindowsPar );	    
	    
		edtHeaderMotifPar = new JTextField();
		edtHeaderMotifPar.setBounds( 520, 30, 70, 20 );
		edtHeaderMotifPar.setEditable( false );
	    painelBrowse.add( edtHeaderMotifPar );
	    lblHeaderMotifPar = new JTextField();
	    lblHeaderMotifPar.setBounds( 595, 30, 30, 20 ); 
	    lblHeaderMotifPar.setEditable( false );
	    painelBrowse.add( lblHeaderMotifPar );
	    
	    btnHeaderMotifPar = new JButton();
	    btnHeaderMotifPar.setBounds( 630, 30, 20, 20 );
	    btnHeaderMotifPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnHeaderMotifPar.addActionListener( this );
	    btnHeaderMotifPar.setActionCommand( "EscolheCor" );
	    btnHeaderMotifPar.setName( "btnHeaderMotifPar" );
	    painelBrowse.add( btnHeaderMotifPar );
	 
		// Primeira Linha
		
		JLabel lblBrowseLinhaPar = new JLabel( "Browse Linha Par" );
		lblBrowseLinhaPar.setBounds( 20, 60, 200, 20 );
		painelBrowse.add( lblBrowseLinhaPar );
		
	    edtBrowseMetalPar = new JTextField();
	    edtBrowseMetalPar.setBounds( 200, 60, 70, 20 );
	    edtBrowseMetalPar.setEditable( false );
	    painelBrowse.add( edtBrowseMetalPar );
	    lblBrowseMetalPar = new JTextField();
	    lblBrowseMetalPar.setBounds( 275, 60, 30, 20 ); 
	    lblBrowseMetalPar.setEditable( false );
	    painelBrowse.add( lblBrowseMetalPar );
	    
	    btnBrowseMetalPar = new JButton();
	    btnBrowseMetalPar.setBounds( 310, 60, 20, 20 );
	    btnBrowseMetalPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseMetalPar.addActionListener( this );
	    btnBrowseMetalPar.setActionCommand( "EscolheCor" );
	    btnBrowseMetalPar.setName( "btnBrowseMetalPar" );
	    painelBrowse.add( btnBrowseMetalPar );
	    
		edtBrowseWindowsPar = new JTextField();
	    edtBrowseWindowsPar.setBounds( 360, 60, 70, 20 );
		edtBrowseWindowsPar.setEditable( false );
	    painelBrowse.add( edtBrowseWindowsPar );
	    lblBrowseWindowsPar = new JTextField();
	    lblBrowseWindowsPar.setBounds( 435, 60, 30, 20 ); 
	    lblBrowseWindowsPar.setEditable( false );
	    painelBrowse.add( lblBrowseWindowsPar );
	    
	    btnBrowseWindowsPar = new JButton();
	    btnBrowseWindowsPar.setBounds( 470, 60, 20, 20 );
	    btnBrowseWindowsPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseWindowsPar.addActionListener( this );
	    btnBrowseWindowsPar.setActionCommand( "EscolheCor" );
	    btnBrowseWindowsPar.setName( "btnBrowseWindowsPar" );
	    painelBrowse.add( btnBrowseWindowsPar );	    
	    
		edtBrowseMotifPar = new JTextField();
		edtBrowseMotifPar.setBounds( 520, 60, 70, 20 );
		edtBrowseMotifPar.setEditable( false );
	    painelBrowse.add( edtBrowseMotifPar );
	    lblBrowseMotifPar = new JTextField();
	    lblBrowseMotifPar.setBounds( 595, 60, 30, 20 ); 
	    lblBrowseMotifPar.setEditable( false );
	    painelBrowse.add( lblBrowseMotifPar );
	    
	    btnBrowseMotifPar = new JButton();
	    btnBrowseMotifPar.setBounds( 630, 60, 20, 20 );
	    btnBrowseMotifPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseMotifPar.addActionListener( this );
	    btnBrowseMotifPar.setActionCommand( "EscolheCor" );
	    btnBrowseMotifPar.setName( "btnBrowseMotifPar" );
	    painelBrowse.add( btnBrowseMotifPar );
	    
		// Segunda Linha
		
		JLabel lblBrowseLinhaImpar = new JLabel( "Browse Linha Impar" );
		lblBrowseLinhaImpar.setBounds( 20, 90, 200, 20 );
		painelBrowse.add( lblBrowseLinhaImpar );
		
	    edtBrowseMetalImpar = new JTextField();
	    edtBrowseMetalImpar.setBounds( 200, 90, 70, 20 );
	    edtBrowseMetalImpar.setEditable( false );
	    painelBrowse.add( edtBrowseMetalImpar );
	    lblBrowseMetalImpar = new JTextField();
	    lblBrowseMetalImpar.setBounds( 275, 90, 30, 20 ); 
	    lblBrowseMetalImpar.setEditable( false );
	    painelBrowse.add( lblBrowseMetalImpar );
	    
	    btnBrowseMetalImpar = new JButton();
	    btnBrowseMetalImpar.setBounds( 310, 90, 20, 20 );
	    btnBrowseMetalImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseMetalImpar.addActionListener( this );
	    btnBrowseMetalImpar.setActionCommand( "EscolheCor" );
	    btnBrowseMetalImpar.setName( "btnBrowseMetalImpar" );
	    painelBrowse.add( btnBrowseMetalImpar );
	    
		edtBrowseWindowsImpar = new JTextField();
	    edtBrowseWindowsImpar.setBounds( 360, 90, 70, 20 );
		edtBrowseWindowsImpar.setEditable( false );
	    painelBrowse.add( edtBrowseWindowsImpar );
	    lblBrowseWindowsImpar = new JTextField();
	    lblBrowseWindowsImpar.setBounds( 435, 90, 30, 20 ); 
	    lblBrowseWindowsImpar.setEditable( false );
	    painelBrowse.add( lblBrowseWindowsImpar );
	    
	    btnBrowseWindowsImpar = new JButton();
	    btnBrowseWindowsImpar.setBounds( 470, 90, 20, 20 );
	    btnBrowseWindowsImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseWindowsImpar.addActionListener( this );
	    btnBrowseWindowsImpar.setActionCommand( "EscolheCor" );
	    btnBrowseWindowsImpar.setName( "btnBrowseWindowsImpar" );
	    painelBrowse.add( btnBrowseWindowsImpar );	    
	    
		edtBrowseMotifImpar = new JTextField();
		edtBrowseMotifImpar.setBounds( 520, 90, 70, 20 );
		edtBrowseMotifImpar.setEditable( false );
	    painelBrowse.add( edtBrowseMotifImpar );
	    lblBrowseMotifImpar = new JTextField();
	    lblBrowseMotifImpar.setBounds( 595, 90, 30, 20 ); 
	    lblBrowseMotifImpar.setEditable( false );
	    painelBrowse.add( lblBrowseMotifImpar );
	    
	    btnBrowseMotifImpar = new JButton();
	    btnBrowseMotifImpar.setBounds( 630, 90, 20, 20 );
	    btnBrowseMotifImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowseMotifImpar.addActionListener( this );
	    btnBrowseMotifImpar.setActionCommand( "EscolheCor" );
	    btnBrowseMotifImpar.setName( "btnBrowseMotifImpar" );
	    painelBrowse.add( btnBrowseMotifImpar );

		// Terceira Linha
		
		JLabel lblBrowselLinhaPar = new JLabel( "Browsel (sel) Linha Par" );
		lblBrowselLinhaPar.setBounds( 20, 120, 200, 20 );
		painelBrowse.add( lblBrowselLinhaPar );
		
	    edtBrowselMetalPar = new JTextField();
	    edtBrowselMetalPar.setBounds( 200, 120, 70, 20 );
	    edtBrowselMetalPar.setEditable( false );
	    painelBrowse.add( edtBrowselMetalPar );
	    lblBrowselMetalPar = new JTextField();
	    lblBrowselMetalPar.setBounds( 275, 120, 30, 20 ); 
	    lblBrowselMetalPar.setEditable( false );
	    painelBrowse.add( lblBrowselMetalPar );
	    
	    btnBrowselMetalPar = new JButton();
	    btnBrowselMetalPar.setBounds( 310, 120, 20, 20 );
	    btnBrowselMetalPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselMetalPar.addActionListener( this );
	    btnBrowselMetalPar.setActionCommand( "EscolheCor" );
	    btnBrowselMetalPar.setName( "btnBrowselMetalPar" );
	    painelBrowse.add( btnBrowselMetalPar );
	    
		edtBrowselWindowsPar = new JTextField();
	    edtBrowselWindowsPar.setBounds( 360, 120, 70, 20 );
		edtBrowselWindowsPar.setEditable( false );
	    painelBrowse.add( edtBrowselWindowsPar );
	    lblBrowselWindowsPar = new JTextField();
	    lblBrowselWindowsPar.setBounds( 435, 120, 30, 20 ); 
	    lblBrowselWindowsPar.setEditable( false );
	    painelBrowse.add( lblBrowselWindowsPar );
	    
	    btnBrowselWindowsPar = new JButton();
	    btnBrowselWindowsPar.setBounds( 470, 120, 20, 20 );
	    btnBrowselWindowsPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselWindowsPar.addActionListener( this );
	    btnBrowselWindowsPar.setActionCommand( "EscolheCor" );
	    btnBrowselWindowsPar.setName( "btnBrowselWindowsPar" );
	    painelBrowse.add( btnBrowselWindowsPar );	    
	    
		edtBrowselMotifPar = new JTextField();
		edtBrowselMotifPar.setBounds( 520, 120, 70, 20 );
		edtBrowselMotifPar.setEditable( false );
	    painelBrowse.add( edtBrowselMotifPar );
	    lblBrowselMotifPar = new JTextField();
	    lblBrowselMotifPar.setBounds( 595, 120, 30, 20 ); 
	    lblBrowselMotifPar.setEditable( false );
	    painelBrowse.add( lblBrowselMotifPar );
	    
	    btnBrowselMotifPar = new JButton();
	    btnBrowselMotifPar.setBounds( 630, 120, 20, 20 );
	    btnBrowselMotifPar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselMotifPar.addActionListener( this );
	    btnBrowselMotifPar.setActionCommand( "EscolheCor" );
	    btnBrowselMotifPar.setName( "btnBrowselMotifPar" );
	    painelBrowse.add( btnBrowselMotifPar );
	    
		// Quarta Linha
		
		JLabel lblBrowselLinhaImpar = new JLabel( "Browse (sel) Linha Impar" );
		lblBrowselLinhaImpar.setBounds( 20, 150, 200, 20 );
		painelBrowse.add( lblBrowselLinhaImpar );
		
	    edtBrowselMetalImpar = new JTextField();
	    edtBrowselMetalImpar.setBounds( 200, 150, 70, 20 );
	    edtBrowselMetalImpar.setEditable( false );
	    painelBrowse.add( edtBrowselMetalImpar );
	    lblBrowselMetalImpar = new JTextField();
	    lblBrowselMetalImpar.setBounds( 275, 150, 30, 20 ); 
	    lblBrowselMetalImpar.setEditable( false );
	    painelBrowse.add( lblBrowselMetalImpar );
	    
	    btnBrowselMetalImpar = new JButton();
	    btnBrowselMetalImpar.setBounds( 310, 150, 20, 20 );
	    btnBrowselMetalImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselMetalImpar.addActionListener( this );
	    btnBrowselMetalImpar.setActionCommand( "EscolheCor" );
	    btnBrowselMetalImpar.setName( "btnBrowselMetalImpar" );
	    painelBrowse.add( btnBrowselMetalImpar );
	    
		edtBrowselWindowsImpar = new JTextField();
	    edtBrowselWindowsImpar.setBounds( 360, 150, 70, 20 );
		edtBrowselWindowsImpar.setEditable( false );
	    painelBrowse.add( edtBrowselWindowsImpar );
	    lblBrowselWindowsImpar = new JTextField();
	    lblBrowselWindowsImpar.setBounds( 435, 150, 30, 20 ); 
	    lblBrowselWindowsImpar.setEditable( false );
	    painelBrowse.add( lblBrowselWindowsImpar );
	    
	    btnBrowselWindowsImpar = new JButton();
	    btnBrowselWindowsImpar.setBounds( 470, 150, 20, 20 );
	    btnBrowselWindowsImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselWindowsImpar.addActionListener( this );
	    btnBrowselWindowsImpar.setActionCommand( "EscolheCor" );
	    btnBrowselWindowsImpar.setName( "btnBrowselWindowsImpar" );
	    painelBrowse.add( btnBrowselWindowsImpar );	    
	    
		edtBrowselMotifImpar = new JTextField();
		edtBrowselMotifImpar.setBounds( 520, 150, 70, 20 );
		edtBrowselMotifImpar.setEditable( false );
	    painelBrowse.add( edtBrowselMotifImpar );
	    lblBrowselMotifImpar = new JTextField();
	    lblBrowselMotifImpar.setBounds( 595, 150, 30, 20 ); 
	    lblBrowselMotifImpar.setEditable( false );
	    painelBrowse.add( lblBrowselMotifImpar );
	    
	    btnBrowselMotifImpar = new JButton();
	    btnBrowselMotifImpar.setBounds( 630, 150, 20, 20 );
	    btnBrowselMotifImpar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnBrowselMotifImpar.addActionListener( this );
	    btnBrowselMotifImpar.setActionCommand( "EscolheCor" );
	    btnBrowselMotifImpar.setName( "btnBrowselMotifImpar" );
	    painelBrowse.add( btnBrowselMotifImpar );	    
	    
		painelBrowse.setPreferredSize( new Dimension( 800, 350 ) );

		// Segunda Aba
		
		JPanel painelCampos = new JPanel( null );
		
		JLabel lblElemento = new JLabel( "Elemento" );
		lblElemento.setBounds( 20, 5, 200, 20 );
		painelCampos.add( lblElemento );
		
		JLabel lblFrente = new JLabel( "Frente" );
		lblFrente.setForeground( Color.BLUE );
		lblFrente.setBounds( 200, 5, 150, 20 );
		painelCampos.add( lblFrente );

		JLabel lblFundo = new JLabel( "Fundo" );
		lblFundo.setForeground( Color.BLUE );
		lblFundo.setBounds( 360, 5, 150, 20 );
		painelCampos.add( lblFundo );
		
		// Cabecalho
		JLabel lblTextoSelecionado = new JLabel( "Texto Selecionado" );
		lblTextoSelecionado.setBounds( 20, 30, 200, 20 );
		painelCampos.add( lblTextoSelecionado );
		
	    edtTextFieldSelectionForeground = new JTextField();
	    edtTextFieldSelectionForeground.setBounds( 200, 30, 70, 20 );
	    edtTextFieldSelectionForeground.setEditable( false );
	    painelCampos.add( edtTextFieldSelectionForeground );
	    lblTextFieldSelectionForeground = new JTextField();
	    lblTextFieldSelectionForeground.setBounds( 275, 30, 30, 20 ); 
	    lblTextFieldSelectionForeground.setEditable( false );
	    painelCampos.add( lblTextFieldSelectionForeground );
	    
	    btnTextFieldSelectionForeground = new JButton();
	    btnTextFieldSelectionForeground.setBounds( 310, 30, 20, 20 );
	    btnTextFieldSelectionForeground.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnTextFieldSelectionForeground.addActionListener( this );
	    btnTextFieldSelectionForeground.setActionCommand( "EscolheCor" );
	    btnTextFieldSelectionForeground.setName( "btnTextFieldSelectionForeground" );
	    painelCampos.add( btnTextFieldSelectionForeground );
	    
	    edtTextFieldSelectionBackground = new JTextField();
	    edtTextFieldSelectionBackground.setBounds( 360, 30, 70, 20 );
	    edtTextFieldSelectionBackground.setEditable( false );
		painelCampos.add( edtTextFieldSelectionBackground );
		lblTextFieldSelectionBackground = new JTextField();
		lblTextFieldSelectionBackground.setBounds( 435, 30, 30, 20 ); 
		lblTextFieldSelectionBackground.setEditable( false );
	    painelCampos.add( lblTextFieldSelectionBackground );
	    
	    btnTextFieldSelectionBackground = new JButton();
	    btnTextFieldSelectionBackground.setBounds( 470, 30, 20, 20 );
	    btnTextFieldSelectionBackground.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnTextFieldSelectionBackground.addActionListener( this );
	    btnTextFieldSelectionBackground.setActionCommand( "EscolheCor" );
	    btnTextFieldSelectionBackground.setName( "btnTextFieldSelectionBackground" );
	    painelCampos.add( btnTextFieldSelectionBackground );	    
	    
		JLabel lblArea = new JLabel( "Area" );
		lblArea.setBounds( 20, 60, 200, 20 );
		painelCampos.add( lblArea );
	    
	    edtTextAreaForeground = new JTextField();
	    edtTextAreaForeground.setBounds( 200, 60, 70, 20 );
	    edtTextAreaForeground.setEditable( false );
	    painelCampos.add( edtTextAreaForeground );
	    lblTextAreaForeground = new JTextField();
	    lblTextAreaForeground.setBounds( 275, 60, 30, 20 ); 
	    lblTextAreaForeground.setEditable( false );
	    painelCampos.add( lblTextAreaForeground );
	    
	    btnTextAreaForeground = new JButton();
	    btnTextAreaForeground.setBounds( 310, 60, 20, 20 );
	    btnTextAreaForeground.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnTextAreaForeground.addActionListener( this );
	    btnTextAreaForeground.setActionCommand( "EscolheCor" );
	    btnTextAreaForeground.setName( "btnTextAreaForeground" );
	    painelCampos.add( btnTextAreaForeground );
	    
	    edtTextAreaBackground = new JTextField();
	    edtTextAreaBackground.setBounds( 360, 60, 70, 20 );
	    edtTextAreaBackground.setEditable( false );
		painelCampos.add( edtTextAreaBackground );
		lblTextAreaBackground = new JTextField();
		lblTextAreaBackground.setBounds( 435, 60, 30, 20 ); 
		lblTextAreaBackground.setEditable( false );
	    painelCampos.add( lblTextAreaBackground );
	    
	    btnTextAreaBackground = new JButton();
	    btnTextAreaBackground.setBounds( 470, 60, 20, 20 );
	    btnTextAreaBackground.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cores.png" ) ) );
	    btnTextAreaBackground.addActionListener( this );
	    btnTextAreaBackground.setActionCommand( "EscolheCor" );
	    btnTextAreaBackground.setName( "btnTextAreaBackground" );
	    painelCampos.add( btnTextAreaBackground );	    
	    
	    painelBrowse.setPreferredSize( new Dimension( 800, 350 ) );

		painelzaoCentro.addTab("Tabela (Browse)", painelBrowse );
		painelzaoCentro.addTab("Campos", painelCampos );
		painelzaoCentro.setPreferredSize( new Dimension( 800, 350 ) );
	    
		carregaCores( trilha );
		
		return painelzaoCentro;
	}

	public static void abreTelaCores( Verto pg ) {
		new Cores( pg );
	}	
	
	public void actionPerformed(ActionEvent arg0) {

		System.out.println( "Entrando ai I: " + arg0.getActionCommand());

		if ( arg0.getActionCommand().equals( "Alterar" ) ) {
			alteraCor();
		} else if ( arg0.getActionCommand().equals( "Restaurar" ) ) {
			System.out.println( "vai restaurar" );
			restauraPadroes();
		} else if ( arg0.getActionCommand().equals( "Cancelar" ) ) {
			cancelaOperacao();
		} else if ( arg0.getActionCommand().equals( "Confirmar" ) ) {
			confirmaOperacao();
		} else if ( arg0.getActionCommand().equals( "Carregar" ) ) {
			carregaTema();
		} else if ( arg0.getActionCommand().equals( "Salvar" ) ) {
			salvaTema();
		} else if ( arg0.getActionCommand().equals( "EscolheCor" ) ) {
			System.out.println( "Entrando ai?");
			JButton b = (JButton) arg0.getSource();
			escolheCor( b.getName() );
		} else if( arg0.getActionCommand().equals( "Finalizar" ) ) {
			System.exit( 0 );
		}
	}
	
	private void alteraCor() {

		estadoCor = ALTERANDO;
		habilitaBotoes();
		edtBrowseWindowsPar.grabFocus();
	}
	
	private void restauraPadroes() {
		
		boolean confirmaRestauracao = 
			JOptionPane.showConfirmDialog( null, "Confirma a restaura��o das cores padr�o? ", "Restauracao", JOptionPane.YES_OPTION ) == 0 ? true : false;

		if( confirmaRestauracao ) {

			Color corEdtHeaderWindowsPar = corHeaderWindowsPar;
			edtHeaderWindowsPar.setText(  corString( corEdtHeaderWindowsPar ) );
			lblHeaderWindowsPar.setBackground( corEdtHeaderWindowsPar );
			Color corEdtHeaderMetalPar = corHeaderMetalPar;
			edtHeaderMetalPar.setText(  corString( corEdtHeaderMetalPar ) );
			lblHeaderMetalPar.setBackground( corEdtHeaderMetalPar );
			Color corEdtHeaderMotifPar = corHeaderMotifPar;
			edtHeaderMotifPar.setText(  corString( corEdtHeaderMotifPar ) );
			lblHeaderMotifPar.setBackground( corEdtHeaderMotifPar );
			
			Color corEdtBrowseWindowsPar = corBrowseWindowsPar;
			edtBrowseWindowsPar.setText(  corString( corEdtBrowseWindowsPar ) );
			lblBrowseWindowsPar.setBackground( corEdtBrowseWindowsPar );
			Color corEdtBrowseMetalPar = corBrowseMetalPar;
			edtBrowseMetalPar.setText(  corString( corEdtBrowseMetalPar ) );
			lblBrowseMetalPar.setBackground( corEdtBrowseMetalPar );
			Color corEdtBrowseMotifPar = corBrowseMotifPar;
			edtBrowseMotifPar.setText(  corString( corEdtBrowseMotifPar ) );
			lblBrowseMotifPar.setBackground( corEdtBrowseMotifPar );
			
			Color corEdtBrowseWindowsImpar = corBrowseWindowsImpar;
			edtBrowseWindowsImpar.setText(  corString( corEdtBrowseWindowsImpar ) );
			lblBrowseWindowsImpar.setBackground( corEdtBrowseWindowsImpar );
			Color corEdtBrowseMetalImpar = corBrowseMetalImpar;
			edtBrowseMetalImpar.setText(  corString( corEdtBrowseMetalImpar ) );
			lblBrowseMetalImpar.setBackground( corEdtBrowseMetalImpar );
			Color corEdtBrowseMotifImpar = corBrowseMotifImpar;
			edtBrowseMotifImpar.setText(  corString( corEdtBrowseMotifImpar ) );
			lblBrowseMotifImpar.setBackground( corEdtBrowseMotifImpar );	
			
			
			Color corEdtBrowselWindowsPar = corBrowselWindowsPar;
			edtBrowselWindowsPar.setText(  corString( corEdtBrowselWindowsPar ) );
			lblBrowselWindowsPar.setBackground( corEdtBrowselWindowsPar );
			Color corEdtBrowselMetalPar = corBrowselMetalPar;
			edtBrowselMetalPar.setText(  corString( corEdtBrowselMetalPar ) );
			lblBrowselMetalPar.setBackground( corEdtBrowselMetalPar );
			Color corEdtBrowselMotifPar = corBrowselMotifPar;
			edtBrowselMotifPar.setText(  corString( corEdtBrowselMotifPar ) );
			lblBrowselMotifPar.setBackground( corEdtBrowselMotifPar );
			
			Color corEdtBrowselWindowsImpar = corBrowselWindowsImpar;
			edtBrowselWindowsImpar.setText(  corString( corEdtBrowselWindowsImpar ) );
			lblBrowselWindowsImpar.setBackground( corEdtBrowselWindowsImpar );
			Color corEdtBrowselMetalImpar = corBrowselMetalImpar;
			edtBrowselMetalImpar.setText(  corString( corEdtBrowselMetalImpar ) );
			lblBrowselMetalImpar.setBackground( corEdtBrowselMetalImpar );
			Color corEdtBrowselMotifImpar = corBrowselMotifImpar;
			edtBrowselMotifImpar.setText(  corString( corEdtBrowselMotifImpar ) );
			lblBrowselMotifImpar.setBackground( corEdtBrowselMotifImpar );				
			
			edtTextFieldSelectionForeground.setText( corString( corTextFieldSelectionForeground ) );
			lblTextFieldSelectionForeground.setBackground( corTextFieldSelectionForeground );
			
			edtTextFieldSelectionBackground.setText( corString( corTextFieldSelectionBackground ) );
			lblTextFieldSelectionBackground.setBackground( corTextFieldSelectionBackground );
			
			edtTextAreaForeground.setText( corString( corTextAreaForeground ) );
			lblTextAreaForeground.setBackground( corTextAreaForeground );
			
			edtTextAreaBackground.setText( corString( corTextAreaBackground ) );
			lblTextAreaBackground.setBackground( corTextAreaBackground );
			
			programaPrincipal.setaCoresUIManager();
			programaPrincipal.repaint();
			
			modificaCor( trilha );
		}
	}	
	
	private static Color pegaDefault( String elemento ) {
		
		Hashtable defaultProps = UIManager.getDefaults();
		
	    return (Color) defaultProps.get( elemento );
	}

	private void confirmaOperacao() {

		modificaCor( trilha );
		estadoCor = CONSULTANDO;
		habilitaBotoes();
	}
	
	private void cancelaOperacao() {

		limpaCampos();
		carregaCores( trilha );
		estadoCor = CONSULTANDO;
		habilitaBotoes();
	}
		
	
	public void habilitaBotoes() {
		
		if ( estadoCor == ALTERANDO ) {
			btnRestaurar.setEnabled( false ); 
			btnAlterar.setEnabled( false );
			btnConfirmar.setEnabled( true );
			btnCancelar.setEnabled( true );
			btnHeaderWindowsPar.setEnabled( true );
			btnHeaderMetalPar.setEnabled( true );
			btnHeaderMotifPar.setEnabled( true );
			btnBrowseWindowsPar.setEnabled( true );
			btnBrowseMetalPar.setEnabled( true );
			btnBrowseMotifPar.setEnabled( true );
			btnBrowseWindowsImpar.setEnabled( true );
			btnBrowseMetalImpar.setEnabled( true );
			btnBrowseMotifImpar.setEnabled( true );
			btnBrowselWindowsPar.setEnabled( true );
			btnBrowselMetalPar.setEnabled( true );
			btnBrowselMotifPar.setEnabled( true );
			btnBrowselWindowsImpar.setEnabled( true );
			btnBrowselMetalImpar.setEnabled( true );
			btnBrowselMotifImpar.setEnabled( true );
			btnTextFieldSelectionForeground.setEnabled( true );
			btnTextFieldSelectionBackground.setEnabled( true );
			btnTextAreaForeground.setEnabled( true );
			btnTextAreaBackground.setEnabled( true );
		} else {
			btnRestaurar.setEnabled( true ); 
			btnAlterar.setEnabled( true );
			btnConfirmar.setEnabled( false );
			btnCancelar.setEnabled( false );
			btnHeaderWindowsPar.setEnabled( false );
			btnHeaderMetalPar.setEnabled( false );
			btnHeaderMotifPar.setEnabled( false );
			btnBrowseWindowsPar.setEnabled( false );
			btnBrowseMetalPar.setEnabled( false );
			btnBrowseMotifPar.setEnabled( false );
			btnBrowseWindowsImpar.setEnabled( false );
			btnBrowseMetalImpar.setEnabled( false );
			btnBrowseMotifImpar.setEnabled( false );
			btnBrowselWindowsPar.setEnabled( false );
			btnBrowselMetalPar.setEnabled( false );
			btnBrowselMotifPar.setEnabled( false );
			btnBrowselWindowsImpar.setEnabled( false );
			btnBrowselMetalImpar.setEnabled( false );
			btnBrowselMotifImpar.setEnabled( false );
			btnTextFieldSelectionForeground.setEnabled( false );
			btnTextFieldSelectionBackground.setEnabled( false );
			btnTextAreaForeground.setEnabled( false );
			btnTextAreaBackground.setEnabled( false );
		}		
		
	}
	
	public void limpaCampos() {
		
		edtHeaderWindowsPar.setText( "" );
		edtHeaderMetalPar.setText( "" );
		edtHeaderMotifPar.setText( "" );
		lblHeaderWindowsPar.setBackground( Color.GRAY );
		lblHeaderMetalPar.setBackground( Color.GRAY );
		lblHeaderMotifPar.setBackground( Color.GRAY );
		edtBrowseWindowsPar.setText( "" );
		edtBrowseMetalPar.setText( "" );
		edtBrowseMotifPar.setText( "" );
		lblBrowseWindowsPar.setBackground( Color.GRAY );
		lblBrowseMetalPar.setBackground( Color.GRAY );
		lblBrowseMotifPar.setBackground( Color.GRAY );
		edtBrowseWindowsImpar.setText( "" );
		edtBrowseMetalImpar.setText( "" );
		edtBrowseMotifImpar.setText( "" );
		lblBrowseWindowsImpar.setBackground( Color.GRAY );
		lblBrowseMetalImpar.setBackground( Color.GRAY );
		lblBrowseMotifImpar.setBackground( Color.GRAY );

		edtBrowselWindowsPar.setText( "" );
		edtBrowselMetalPar.setText( "" );
		edtBrowselMotifPar.setText( "" );
		lblBrowselWindowsPar.setBackground( Color.GRAY );
		lblBrowselMetalPar.setBackground( Color.GRAY );
		lblBrowselMotifPar.setBackground( Color.GRAY );
		edtBrowselWindowsImpar.setText( "" );
		edtBrowselMetalImpar.setText( "" );
		edtBrowselMotifImpar.setText( "" );
		lblBrowselWindowsImpar.setBackground( Color.GRAY );
		lblBrowselMetalImpar.setBackground( Color.GRAY );
		lblBrowselMotifImpar.setBackground( Color.GRAY );
		

		edtTextFieldSelectionForeground.setText( "" );
		lblTextFieldSelectionForeground.setBackground( Color.GRAY );

		edtTextFieldSelectionBackground.setText( "" );
		lblTextFieldSelectionBackground.setBackground( Color.GRAY );

		edtTextAreaForeground.setText( "" );
		lblTextAreaForeground.setBackground( Color.GRAY );

		edtTextAreaBackground.setText( "" );
		lblTextAreaBackground.setBackground( Color.GRAY );
	}
	
	public static Cores getInstance() {
		return mySelf;
	}

	private void modificaCor( String nomeCaminho ) {

		queries = new Properties();
		
		try {
			try {
				queries.load(new FileInputStream( trilha ) );
			} catch (FileNotFoundException e) {
				queries.store( new FileOutputStream( trilha ), "criando tabela" );
				queries.load(new FileInputStream( trilha ) );
			}
			
			
			queries.setProperty( "edtHeaderWindowsPar", edtHeaderWindowsPar.getText() );
			queries.setProperty( "edtHeaderMetalPar", edtHeaderMetalPar.getText() );
			queries.setProperty( "edtHeaderMotifPar", edtHeaderMotifPar.getText() );
			queries.setProperty( "edtBrowseWindowsPar", edtBrowseWindowsPar.getText() );
			queries.setProperty( "edtBrowseMetalPar", edtBrowseMetalPar.getText() );
			queries.setProperty( "edtBrowseMotifPar", edtBrowseMotifPar.getText() );
			queries.setProperty( "edtBrowseWindowsImpar", edtBrowseWindowsImpar.getText() );
			queries.setProperty( "edtBrowseMetalImpar", edtBrowseMetalImpar.getText() );
			queries.setProperty( "edtBrowseMotifImpar", edtBrowseMotifImpar.getText() );
			queries.setProperty( "edtBrowselWindowsPar", edtBrowselWindowsPar.getText() );
			queries.setProperty( "edtBrowselMetalPar", edtBrowselMetalPar.getText() );
			queries.setProperty( "edtBrowselMotifPar", edtBrowselMotifPar.getText() );
			queries.setProperty( "edtBrowselWindowsImpar", edtBrowselWindowsImpar.getText() );
			queries.setProperty( "edtBrowselMetalImpar", edtBrowselMetalImpar.getText() );
			queries.setProperty( "edtBrowselMotifImpar", edtBrowselMotifImpar.getText() );

			queries.setProperty( "edtTextFieldSelectionForeground", edtTextFieldSelectionForeground.getText() );
			queries.setProperty( "edtTextFieldSelectionBackground", edtTextFieldSelectionBackground.getText() );

			queries.setProperty( "edtTextAreaForeground", edtTextAreaForeground.getText() );
			queries.setProperty( "edtTextAreaBackground", edtTextAreaBackground.getText() );

			queries.store(new FileOutputStream( nomeCaminho ), "modificado em " + Calendar.getInstance() );
			
			Cor.carregaCores( nomeCaminho );
			
			programaPrincipal.setaCoresUIManager();
			programaPrincipal.repaint();
			

		} catch (FileNotFoundException e) {
			System.out.println( programaPrincipal+ "Cores"+ "modificaCor"+ "Arquivo n�o encontrado!"+ "Contate a Quatro Inform�tica Ltda!" );
		} catch (IOException e) {
			System.out.println( programaPrincipal+ "Cores"+ "modificaCor"+ "Problemas no acesso ao arquivo: Cors.txt!"+ "Contate a Quatro Inform�tica Ltda!" );
		}
	}	

	private void carregaCores( String nomeCaminho ) {
		
	    queries = new Properties();

		try {
			try {
				queries.load(new FileInputStream( nomeCaminho ) );
			} catch (FileNotFoundException e) {
				queries.store( new FileOutputStream( nomeCaminho ), "criando tabela" );
				queries.load(new FileInputStream( nomeCaminho ) );
			}
			
			Color corEdtHeaderWindowsPar = Cores.buscaCor( Cores.HEADER_WINDOWS_PAR, nomeCaminho );
			edtHeaderWindowsPar.setText(  corString( corEdtHeaderWindowsPar ) );
			lblHeaderWindowsPar.setBackground( corEdtHeaderWindowsPar );
			
			Color corEdtHeaderMetalPar = Cores.buscaCor( Cores.HEADER_METAL_PAR, nomeCaminho );
			edtHeaderMetalPar.setText(  corString( corEdtHeaderMetalPar ) );
			lblHeaderMetalPar.setBackground( corEdtHeaderMetalPar );

			Color corEdtHeaderMotifPar = Cores.buscaCor( Cores.HEADER_MOTIF_PAR, nomeCaminho );
			edtHeaderMotifPar.setText(  corString( corEdtHeaderMotifPar ) );
			lblHeaderMotifPar.setBackground( corEdtHeaderMotifPar );
			
			Color corEdtBrowseWindowsPar = Cores.buscaCor( Cores.BROWSE_WINDOWS_PAR, nomeCaminho );
			edtBrowseWindowsPar.setText(  corString( corEdtBrowseWindowsPar ) );
			lblBrowseWindowsPar.setBackground( corEdtBrowseWindowsPar );
			
			Color corEdtBrowseMetalPar = Cores.buscaCor( Cores.BROWSE_METAL_PAR, nomeCaminho );
			edtBrowseMetalPar.setText(  corString( corEdtBrowseMetalPar ) );
			lblBrowseMetalPar.setBackground( corEdtBrowseMetalPar );

			Color corEdtBrowseMotifPar = Cores.buscaCor( Cores.BROWSE_MOTIF_PAR, nomeCaminho );
			edtBrowseMotifPar.setText(  corString( corEdtBrowseMotifPar ) );
			lblBrowseMotifPar.setBackground( corEdtBrowseMotifPar );

			Color corEdtBrowseWindowsImpar = Cores.buscaCor( Cores.BROWSE_WINDOWS_IMPAR, nomeCaminho );
			edtBrowseWindowsImpar.setText(  corString( corEdtBrowseWindowsImpar ) );
			lblBrowseWindowsImpar.setBackground( corEdtBrowseWindowsImpar );
			
			Color corEdtBrowseMetalImpar = Cores.buscaCor( Cores.BROWSE_METAL_IMPAR, nomeCaminho );
			edtBrowseMetalImpar.setText(  corString( corEdtBrowseMetalImpar ) );
			lblBrowseMetalImpar.setBackground( corEdtBrowseMetalImpar );

			Color corEdtBrowseMotifImpar = Cores.buscaCor( Cores.BROWSE_MOTIF_IMPAR, nomeCaminho );
			edtBrowseMotifImpar.setText(  corString( corEdtBrowseMotifImpar ) );
			lblBrowseMotifImpar.setBackground( corEdtBrowseMotifImpar );
			
			Color corEdtBrowselWindowsPar = Cores.buscaCor( Cores.BROWSE_SEL_WINDOWS_PAR, nomeCaminho );
			edtBrowselWindowsPar.setText(  corString( corEdtBrowselWindowsPar ) );
			lblBrowselWindowsPar.setBackground( corEdtBrowselWindowsPar );
			
			Color corEdtBrowselMetalPar = Cores.buscaCor( Cores.BROWSE_SEL_METAL_PAR, nomeCaminho );
			edtBrowselMetalPar.setText(  corString( corEdtBrowselMetalPar ) );
			lblBrowselMetalPar.setBackground( corEdtBrowselMetalPar );

			Color corEdtBrowselMotifPar = Cores.buscaCor( Cores.BROWSE_SEL_MOTIF_PAR, nomeCaminho );
			edtBrowselMotifPar.setText(  corString( corEdtBrowselMotifPar ) );
			lblBrowselMotifPar.setBackground( corEdtBrowselMotifPar );

			Color corEdtBrowselWindowsImpar = Cores.buscaCor( Cores.BROWSE_SEL_WINDOWS_IMPAR, nomeCaminho );
			edtBrowselWindowsImpar.setText(  corString( corEdtBrowselWindowsImpar ) );
			lblBrowselWindowsImpar.setBackground( corEdtBrowselWindowsImpar );
			
			Color corEdtBrowselMetalImpar = Cores.buscaCor( Cores.BROWSE_SEL_METAL_IMPAR, nomeCaminho );
			edtBrowselMetalImpar.setText(  corString( corEdtBrowselMetalImpar ) );
			lblBrowselMetalImpar.setBackground( corEdtBrowselMetalImpar );

			Color corEdtBrowselMotifImpar = Cores.buscaCor( Cores.BROWSE_SEL_MOTIF_IMPAR, nomeCaminho );
			edtBrowselMotifImpar.setText(  corString( corEdtBrowselMotifImpar ) );
			lblBrowselMotifImpar.setBackground( corEdtBrowselMotifImpar );

			Color corEdtTextFieldSelectionForeground = Cores.buscaCor( Cores.TEXTFIELD_SELECTION_FOREGROUND, nomeCaminho );
			edtTextFieldSelectionForeground.setText(  corString( corEdtTextFieldSelectionForeground ) );
			lblTextFieldSelectionForeground.setBackground( corEdtTextFieldSelectionForeground );

			Color corEdtTextFieldSelectionBackground = Cores.buscaCor( Cores.TEXTFIELD_SELECTION_BACKGROUND, nomeCaminho );
			edtTextFieldSelectionBackground.setText(  corString( corEdtTextFieldSelectionBackground ) );
			lblTextFieldSelectionBackground.setBackground( corEdtTextFieldSelectionBackground );

			Color corEdtTextAreaForeground = Cores.buscaCor( Cores.TEXTAREA_FOREGROUND, nomeCaminho );
			edtTextAreaForeground.setText(  corString( corEdtTextAreaForeground ) );
			lblTextAreaForeground.setBackground( corEdtTextAreaForeground );

			Color corEdtTextAreaBackground = Cores.buscaCor( Cores.TEXTAREA_BACKGROUND, nomeCaminho );
			edtTextAreaBackground.setText(  corString( corEdtTextAreaBackground ) );
			lblTextAreaBackground.setBackground( corEdtTextAreaBackground );

			programaPrincipal.setaCoresUIManager();
			programaPrincipal.repaint();
			
		} catch (FileNotFoundException e) {
			System.out.println( programaPrincipal+ "AplicativosJTable"+ "carregaAplicativos"+ "Arquivo n�o encontrado!"+ "Contate a Quatro Inform�tica Ltda!" );
		} catch (IOException e) {
			System.out.println( programaPrincipal+ "AplicativosJTable"+ "carregaAplicativos"+ "Problemas no acesso ao arquivo: VertoExt.txt!"+ "Contate a Quatro Inform�tica Ltda!" );
		}
	}
	
	public static Color buscaCor( int identificacao, String caminho ) {

		propriedades = new Properties();

		
		try {
			propriedades.load(new FileInputStream( caminho ) );
			switch ( identificacao ) {
			case HEADER_WINDOWS_PAR: {
					if ( propriedades.getProperty( "edtHeaderWindowsPar" ) == null ) {
						return corHeaderWindowsPar;
					} else {
						String cor = propriedades.getProperty( "edtHeaderWindowsPar" );
						return stringCor( cor );
					}
				}
			case HEADER_METAL_PAR: {
					if ( propriedades.getProperty( "edtHeaderMetalPar" ) == null ) {
						return corHeaderMetalPar;
					} else {
						String cor = propriedades.getProperty( "edtHeaderMetalPar" );
						return stringCor( cor );
					}
				}
			case HEADER_MOTIF_PAR: {
					if ( propriedades.getProperty( "edtHeaderMotifPar" ) == null ) {
						return corHeaderMotifPar;
					} else {
						String cor = propriedades.getProperty( "edtHeaderMotifPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_WINDOWS_PAR: {
					if ( propriedades.getProperty( "edtBrowseWindowsPar" ) == null ) {
						return corBrowseWindowsPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseWindowsPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_METAL_PAR: {
					if ( propriedades.getProperty( "edtBrowseMetalPar" ) == null ) {
						return corBrowseMetalPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseMetalPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_MOTIF_PAR: {
					if ( propriedades.getProperty( "edtBrowseMotifPar" ) == null ) {
						return corBrowseMotifPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseMotifPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_WINDOWS_IMPAR: {
					if ( propriedades.getProperty( "edtBrowseWindowsImpar" ) == null ) {
						return corBrowseWindowsImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseWindowsImpar" );
						return stringCor( cor );
					}
				}
			case BROWSE_METAL_IMPAR: {
					if ( propriedades.getProperty( "edtBrowseMetalImpar" ) == null ) {
						return corBrowseMetalImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseMetalImpar" );
						return stringCor( cor );
					}
				}
			case BROWSE_MOTIF_IMPAR: {
					if ( propriedades.getProperty( "edtBrowseMotifImpar" ) == null ) {
						return corBrowseMotifImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowseMotifImpar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_WINDOWS_PAR: {
					if ( propriedades.getProperty( "edtBrowselWindowsPar" ) == null ) {
						return corBrowselWindowsPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselWindowsPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_METAL_PAR: {
					if ( propriedades.getProperty( "edtBrowselMetalPar" ) == null ) {
						return corBrowselMetalPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselMetalPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_MOTIF_PAR: {
					if ( propriedades.getProperty( "edtBrowselMotifPar" ) == null ) {
						return corBrowselMotifPar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselMotifPar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_WINDOWS_IMPAR: {
					if ( propriedades.getProperty( "edtBrowselWindowsImpar" ) == null ) {
						return corBrowselWindowsImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselWindowsImpar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_METAL_IMPAR: {
					if ( propriedades.getProperty( "edtBrowselMetalImpar" ) == null ) {
						return corBrowselMetalImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselMetalImpar" );
						return stringCor( cor );
					}
				}
			case BROWSE_SEL_MOTIF_IMPAR: {
					if ( propriedades.getProperty( "edtBrowselMotifImpar" ) == null ) {
						return corBrowselMotifImpar;
					} else {
						String cor = propriedades.getProperty( "edtBrowselMotifImpar" );
						return stringCor( cor );
					}
				}			
		
			
			
			case TEXTFIELD_SELECTION_FOREGROUND: {
					if ( propriedades.getProperty( "edtTextFieldSelectionForeground" ) == null ) {
						return corTextFieldSelectionForeground;
					} else {
						String cor = propriedades.getProperty( "edtTextFieldSelectionForeground" );
						return stringCor( cor );
					}
				}			
			
			case TEXTFIELD_SELECTION_BACKGROUND: {
					if ( propriedades.getProperty( "edtTextFieldSelectionBackground" ) == null ) {
						return corTextFieldSelectionBackground;
					} else {
						String cor = propriedades.getProperty( "edtTextFieldSelectionBackground" );
						return stringCor( cor );
					}
				}			
			case TEXTAREA_FOREGROUND: {
				if ( propriedades.getProperty( "edtTextAreaForeground" ) == null ) {
					return corTextAreaForeground;
				} else {
					String cor = propriedades.getProperty( "edtTextAreaForeground" );
					return stringCor( cor );
				}
			}			
		
			case TEXTAREA_BACKGROUND: {
				if ( propriedades.getProperty( "edtTextAreaBackground" ) == null ) {
					return corTextAreaBackground;
				} else {
					String cor = propriedades.getProperty( "edtTextAreaBackground" );
					return stringCor( cor );
				}
			}			
			
			}
			
		} catch (Exception e) {
			switch ( identificacao ) {
			case HEADER_WINDOWS_PAR: return corHeaderWindowsPar;
			case HEADER_METAL_PAR: return corHeaderMetalPar;
			case HEADER_MOTIF_PAR: return corHeaderMotifPar;
			case BROWSE_WINDOWS_PAR: return corBrowseWindowsPar;
			case BROWSE_METAL_PAR: return corBrowseMetalPar;
			case BROWSE_MOTIF_PAR: return corBrowseMotifPar;
			case BROWSE_WINDOWS_IMPAR: return corBrowseWindowsImpar;
			case BROWSE_METAL_IMPAR: return corBrowseMetalImpar;
			case BROWSE_MOTIF_IMPAR: return corBrowseMotifImpar;
			case BROWSE_SEL_WINDOWS_PAR: return corBrowselWindowsPar;
			case BROWSE_SEL_METAL_PAR: return corBrowselMetalPar;
			case BROWSE_SEL_MOTIF_PAR: return corBrowselMotifPar;
			case BROWSE_SEL_WINDOWS_IMPAR: return corBrowselWindowsImpar;
			case BROWSE_SEL_METAL_IMPAR: return corBrowselMetalImpar;
			case BROWSE_SEL_MOTIF_IMPAR: return corBrowselMotifImpar;			

			case TEXTFIELD_SELECTION_FOREGROUND: return corTextFieldSelectionForeground;	
			case TEXTFIELD_SELECTION_BACKGROUND: return corTextFieldSelectionBackground;	
			case TEXTAREA_FOREGROUND: return corTextAreaForeground;	
			case TEXTAREA_BACKGROUND: return corTextAreaBackground;	
			}
		}
		return null;
	}
	
	private void escolheCor( String name ) {

		System.out.println( "Escolhendo cor: " + name );
		
		JColorChooser colorChooser = new JColorChooser();
		
		if ( name.equalsIgnoreCase( "btnHeaderWindowsPar" ) ) {
			Color newColor = JColorChooser.showDialog(
                    this,
                    "Escolha a Cor",
                    Cor.headerWindowsPar );
			if ( newColor == null ) newColor = Cor.headerWindowsPar;
			edtHeaderWindowsPar.setText( corString( newColor ) ); 
			lblHeaderWindowsPar.setBackground( newColor );
		} else {
			if ( name.equalsIgnoreCase( "btnHeaderMetalPar" ) ) {
				Color newColor = JColorChooser.showDialog(
	                    this,
	                    "Escolha a Cor",
	                    Cor.headerMetalPar );
				if ( newColor == null ) newColor = Cor.headerMetalPar;
				edtHeaderMetalPar.setText( corString( newColor ) ); 
				lblHeaderMetalPar.setBackground( newColor );
			} else {
				if ( name.equalsIgnoreCase( "btnHeaderMotifPar" ) ) {
					Color newColor = JColorChooser.showDialog(
		                    this,
		                    "Escolha a Cor",
		                    Cor.headerMotifPar );
					if ( newColor == null ) newColor = Cor.headerMotifPar;
					edtHeaderMotifPar.setText( corString( newColor ) ); 
					lblHeaderMotifPar.setBackground( newColor );
				} else {
					if ( name.equalsIgnoreCase( "btnBrowseWindowsPar" ) ) {
						Color newColor = JColorChooser.showDialog(
			                    this,
			                    "Escolha a Cor",
			                    Cor.browseWindowsPar );
						if ( newColor == null ) newColor = Cor.browseWindowsPar;
						edtBrowseWindowsPar.setText( corString( newColor ) ); 
						lblBrowseWindowsPar.setBackground( newColor );
					} else {
						if ( name.equalsIgnoreCase( "btnBrowseMetalPar" ) ) {
							Color newColor = JColorChooser.showDialog(
				                    this,
				                    "Escolha a Cor",
				                    Cor.browseMetalPar );
							if ( newColor == null ) newColor = Cor.browseMetalPar;
							edtBrowseMetalPar.setText( corString( newColor ) ); 
							lblBrowseMetalPar.setBackground( newColor );
						} else {
							if ( name.equalsIgnoreCase( "btnBrowseMotifPar" ) ) {
								Color newColor = JColorChooser.showDialog(
					                    this,
					                    "Escolha a Cor",
					                    Cor.browseMotifPar );
								if ( newColor == null ) newColor = Cor.browseMotifPar;
								edtBrowseMotifPar.setText( corString( newColor ) ); 
								lblBrowseMotifPar.setBackground( newColor );
							} else {
								if ( name.equalsIgnoreCase( "btnBrowseWindowsImpar" ) ) {
									Color newColor = JColorChooser.showDialog(
						                    this,
						                    "Escolha a Cor",
						                    Cor.browseWindowsImpar );
									if ( newColor == null ) newColor = Cor.browseWindowsImpar;
									edtBrowseWindowsImpar.setText( corString( newColor ) ); 
									lblBrowseWindowsImpar.setBackground( newColor );
								} else {
									if ( name.equalsIgnoreCase( "btnBrowseMetalImpar" ) ) {
										Color newColor = JColorChooser.showDialog(
							                    this,
							                    "Escolha a Cor",
							                    Cor.browseMetalImpar );
										if ( newColor == null ) newColor = Cor.browseMetalImpar;
										edtBrowseMetalImpar.setText( corString( newColor ) ); 
										lblBrowseMetalImpar.setBackground( newColor );
									} else {
										if ( name.equalsIgnoreCase( "btnBrowseMotifImpar" ) ) {
											Color newColor = JColorChooser.showDialog(
								                    this,
								                    "Escolha a Cor",
								                    Cor.browseMotifImpar );
											if ( newColor == null ) newColor = Cor.browseMotifImpar;
											edtBrowseMotifImpar.setText( corString( newColor ) ); 
											lblBrowseMotifImpar.setBackground( newColor );
										} else {
											if ( name.equalsIgnoreCase( "btnBrowselWindowsPar" ) ) {
												Color newColor = JColorChooser.showDialog(
									                    this,
									                    "Escolha a Cor",
									                    Cor.browselWindowsPar );
												if ( newColor == null ) newColor = Cor.browselWindowsPar;
												edtBrowselWindowsPar.setText( corString( newColor ) ); 
												lblBrowselWindowsPar.setBackground( newColor );
											} else {
												if ( name.equalsIgnoreCase( "btnBrowselMetalPar" ) ) {
													Color newColor = JColorChooser.showDialog(
										                    this,
										                    "Escolha a Cor",
										                    Cor.browselMetalPar );
													if ( newColor == null ) newColor = Cor.browselMetalPar;
													edtBrowselMetalPar.setText( corString( newColor ) ); 
													lblBrowselMetalPar.setBackground( newColor );
												} else {
													if ( name.equalsIgnoreCase( "btnBrowselMotifPar" ) ) {
														Color newColor = JColorChooser.showDialog(
											                    this,
											                    "Escolha a Cor",
											                    Cor.browselMotifPar );
														if ( newColor == null ) newColor = Cor.browselMotifPar;
														edtBrowselMotifPar.setText( corString( newColor ) ); 
														lblBrowselMotifPar.setBackground( newColor );
													} else {
														if ( name.equalsIgnoreCase( "btnBrowselWindowsImpar" ) ) {
															Color newColor = JColorChooser.showDialog(
												                    this,
												                    "Escolha a Cor",
												                    Cor.browselWindowsImpar );
															if ( newColor == null ) newColor = Cor.browselWindowsImpar;
															edtBrowselWindowsImpar.setText( corString( newColor ) ); 
															lblBrowselWindowsImpar.setBackground( newColor );
														} else {
															if ( name.equalsIgnoreCase( "btnBrowselMetalImpar" ) ) {
																Color newColor = JColorChooser.showDialog(
													                    this,
													                    "Escolha a Cor",
													                    Cor.browselMetalImpar );
																if ( newColor == null ) newColor = Cor.browselMetalImpar;
																edtBrowselMetalImpar.setText( corString( newColor ) ); 
																lblBrowselMetalImpar.setBackground( newColor );
															} else {
																if ( name.equalsIgnoreCase( "btnBrowselMotifImpar" ) ) {
																	Color newColor = JColorChooser.showDialog(
														                    this,
														                    "Escolha a Cor",
														                    Cor.browselMotifImpar );
																	if ( newColor == null ) newColor = Cor.browselMotifImpar;
																	edtBrowselMotifImpar.setText( corString( newColor ) ); 
																	lblBrowselMotifImpar.setBackground( newColor );
																} else {
																	if ( name.equalsIgnoreCase( "btnTextFieldSelectionForeground" ) ) {
																		Color newColor = JColorChooser.showDialog(
															                    this,
															                    "Escolha a Cor",
															                    Cor.textFieldSelectionForeground );
																		if ( newColor == null ) newColor = pegaDefault( "TextField.selectionForeground" );
																		edtTextFieldSelectionForeground.setText( corString( newColor ) ); 
																		lblTextFieldSelectionForeground.setBackground( newColor );
																	} else {
																		if ( name.equalsIgnoreCase( "btnTextFieldSelectionBackground" ) ) {
																			Color newColor = JColorChooser.showDialog(
																                    this,
																                    "Escolha a Cor",
																                    Cor.textFieldSelectionBackground );
																			if ( newColor == null ) newColor = pegaDefault( "TextField.selectionBackground" );
																				edtTextFieldSelectionBackground.setText( corString( newColor ) ); 
																				lblTextFieldSelectionBackground.setBackground( newColor );
																			} else {
																				if ( name.equalsIgnoreCase( "btnTextAreaForeground" ) ) {
																					Color newColor = JColorChooser.showDialog(
																							this,
																							"Escolha a Cor",
																							Cor.textAreaForeground );
																					if ( newColor == null ) newColor = pegaDefault( "TextArea.foreground" );
																						edtTextAreaForeground.setText( corString( newColor ) ); 
																						lblTextAreaForeground.setBackground( newColor );
																					} else {
																						if ( name.equalsIgnoreCase( "btnTextAreaBackground" ) ) {
																							Color newColor = JColorChooser.showDialog(
																									this,
																									"Escolha a Cor",
																									Cor.textAreaBackground );
																							if ( newColor == null ) newColor = pegaDefault( "TextArea.background" );
																								edtTextAreaBackground.setText( corString( newColor ) ); 
																								lblTextAreaBackground.setBackground( newColor );
																							} else {
																					
																							}
																			}																		}
																	}													
																}				
															}
														}					
													}				
												}
											}											
										}				
									}
								}					
							}				
						}
					}					
				}				
			}
		}
	}

	private static Color stringCor( String hexa ) {

		int red = 0;
		int green = 0;
		int blue = 0;

		red = Integer.parseInt(hexa.substring(0,2), 16); 
		green = Integer.parseInt(hexa.substring(2,4), 16); 
		blue = Integer.parseInt(hexa.substring(4,6), 16);
		
		return ( new Color( red, green, blue ) );
	}
	
	private String corString( Color cor ) {
		
		String corFormatada = byte2Hex( cor.getRed() ) + byte2Hex( cor.getGreen() ) + byte2Hex( cor.getBlue() );
		
		return corFormatada;
	}
	
	private String byte2Hex( int n ) {

	    String retorno = strHexaZero( Integer.toHexString( n ), 2 );
	    return retorno;
	}
	
	public static String strHexaZero( String vl, int tam ) {
        
    	StringBuilder result = new StringBuilder();
        
        result.append( vl );
        
        while( result.length() < tam ) {
            result.insert( 0, '0' );
        }
        
        return result.toString();
    }
	
	private void carregaTema() {

		JFileChooser fileChooser = new JFileChooser();
		
		fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );

		FiltroTema filtro = new FiltroTema();
	    
		fileChooser.addChoosableFileFilter( filtro );
		
		int result = fileChooser.showOpenDialog( c );
		
		if( result == JFileChooser.CANCEL_OPTION ) {
			return;
		}
		
		fileName = fileChooser.getSelectedFile();

		carregaCores( fileName.getAbsoluteFile().toString() );
		modificaCor( trilha );
	}

	private void salvaTema() {
		
		JFileChooser fileChooser = new JFileChooser();
		
		int result = fileChooser.showSaveDialog( c );
		
		if( result == JFileChooser.CANCEL_OPTION ) {
			return;
		}
		
		fileName = fileChooser.getSelectedFile();
		
		String nomeTema = fileName.getAbsoluteFile().toString() + ".tma";
		
		if( fileName == null || fileName.getName().trim().equals( "" ) ) {
			JOptionPane.showMessageDialog( c, "Nome de Arquivo Inv�lido", "Nome de Arquivo Inv�lido", JOptionPane.ERROR_MESSAGE );
		} else {
			modificaCor( nomeTema );
			modificaCor( trilha );
		}
	}


}