package verto.semantico;
import verto.exception.ErroSemanticoException;
import verto.lexico.Lexico;

/*
 * $Id: SimboloTabela.java,v 1.2 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *   
 */

/**
 * Classe SimboloTabela
 * 
 * Esta classe modela objetos que comp�e a Tabela de S�mbolos.
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroSemanticoException
 * 
 * @version 2.6.2
 */
public class SimboloTabela {
	
	public static final int T_GLOBAL			= 1;
	public static final int T_LOCAL  			= 2; // Serve tamb�m para parametros
	public static final int T_FUNCAO			= 3;
	public static final int T_PROTOTIPO			= 4;
	
	private boolean ativa;
	private boolean parametro; 
	private String  nome;
	private int     tipo;
	private int     classe;
	private int     endereco;
	private boolean declarada; /* Para checar se esta entrada foi a partir de uma chamada ou de uma declaracao  */
	private String  contexto;
	private int[]   tipoParametros;
	private boolean constante = false;
	private boolean vetor = false;
	
	public SimboloTabela() {
	}

	public SimboloTabela( String nome, int tipo, int classe ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.endereco = 0;
		this.declarada = false;
		this.contexto = " ";
		this.tipoParametros = null;
	}

	public SimboloTabela( String nome, int tipo, int classe, String contexto ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.endereco = 0;
		this.declarada = false;
		this.contexto = contexto;
		this.tipoParametros = null;
	}
	
	public SimboloTabela( String nome, int tipo, int classe, boolean declarada, int[] tipoParametros ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.declarada = declarada;
		this.contexto = " ";
		this.tipoParametros = tipoParametros; 
	}
	
	
	public SimboloTabela( String nome, int tipo, int classe, boolean constante, boolean vetor ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.endereco = 0;
		this.declarada = false;
		this.contexto = " ";
		this.tipoParametros = null;
		this.constante = constante;
		this.vetor = vetor;
	}

	public SimboloTabela( String nome, int tipo, int classe, String contexto, boolean constante, boolean vetor ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.endereco = 0;
		this.declarada = false;
		this.contexto = contexto;
		this.tipoParametros = null;
		this.constante = constante;
		this.vetor = vetor;
	}
	
	public SimboloTabela( String nome, int tipo, int classe, boolean declarada, int[] tipoParametros, boolean constante, boolean vetor ) {
		
		this.ativa = true;
		this.parametro = false;
		this.nome   = nome;
		this.tipo   = tipo;
		this.classe = classe;
		this.declarada = declarada;
		this.contexto = " ";
		this.tipoParametros = tipoParametros; 
		this.constante = constante;
		this.vetor = vetor;
	}
	
	/**
	 * @return Returns the parametro.
	 */
	public boolean isParametro() {
		return parametro;
	}
	/**
	 * @param parametro The parametro to set.
	 */
	public void setParametro(boolean parametro) {
		this.parametro = parametro;
	}
	
	/**
	 * @return Returns the ativa.
	 */
	public boolean isAtiva() {
		return ativa;
	}
	/**
	 * @param ativa The ativa to set.
	 */
	public void setAtiva(boolean ativa) {
		this.ativa = ativa;
	}
	/**
	 * @return Returns the declarada.
	 */
	public boolean isDeclarada() {
		return declarada;
	}
	/**
	 * @param declarada The declarada to set.
	 */
	public void setDeclarada(boolean declarada) {
		this.declarada = declarada;
	}
	
	/**
	 * @return Returns the classe.
	 */
	public int getClasse() {
		return classe;
	}
	/**
	 * @param classe The classe to set.
	 */
	public void setClasse( int classe ) {
		this.classe = classe;
	}
	/**
	 * @return Returns the endereco.
	 */
	public int getEndereco() {
		return endereco;
	}
	/**
	 * @param endereco The endereco to set.
	 */
	public void setEndereco( int endereco ) {
		this.endereco = endereco;
	}
	/**
	 * @return Returns the nome.
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome The nome to set.
	 */
	public void setNome( String nome ) {
		this.nome = nome;
	}
	/**
	 * @return Returns the tipo.
	 */
	public int getTipo() {
		return tipo;
	}
	/**
	 * @param tipo The tipo to set.
	 */
	public void setTipo( int tipo ) {
		this.tipo = tipo;
	}
	/**
	 * @return Returns the tipoParametros.
	 */
	public int[] getTipoParametros() {
		return tipoParametros;
	}
	/**
	 * @param tipoParametros The tipoParametros to set.
	 */
	public void setTipoParametros( int[] tipoParametros ) {
		this.tipoParametros = tipoParametros;
	}
	
	
	public static String getDsClasse( int classe ) {
		switch ( classe ) {
		case T_FUNCAO: return "T_FUNCAO"; 
		case T_GLOBAL: return "T_GLOBAL"; 
		case T_LOCAL: return "T_LOCAL"; 
		case T_PROTOTIPO: return "T_PROTOTIPO"; 
		default: return "T_DESCONHECIDO";
		}
	}

	public String getContexto() {
		return contexto; 
	}

	public void setContexto(String contexto) {
		this.contexto = contexto;
	}
	
	public boolean isConstante() {
		return constante;
	}

	public void setConstante(boolean constante) {
		this.constante = constante;
	}

	public boolean isVetor() {
		return vetor;
	}

	public void setVetor(boolean vetor) {
		this.vetor = vetor;
	}

}