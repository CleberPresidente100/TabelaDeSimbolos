package verto.semantico;

/*
 * $Id: Semantico.java,v 1.8 2008/04/24 12:01:25 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 */

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;

import javax.swing.JTable;

import verto.Verto;
import verto.VertoAsm;
import verto.exception.ErroSemanticoException;
import verto.lexico.Lexico;
import verto.sintatico.Sintatico;

/**
 * Classe: Analisador Sem�ntico
 * 
 * Este Analisador Sem�ntico toma as suas a��es baseado na chamada do Sint�tico.
 * Este, por sua vez, chama o Sem�ntico a cada vez que reconhece uma regra. Esta
 * t�cnica � conhecida como Tradu��o Dirigida pela Sintaxe.
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * @author Vandersilvio da Silva
 * 
 * @see Sintatico
 * @see Semantico
 * @see PilhaSemantica
 * @see VertoAsm
 * @see ErroSemanticoException
 * 
 * @version 2.6.2
 */
public class Semantico {

	public static final int T_SEM_TIPO = 0; // N�o sei se uso
	public static final int T_STRING = 1;
	public static final int T_INTEGER = 2;
	public static final int T_INT = 3;

	public static final int T_OP_OP = 0;
	public static final int T_PILHA_OP = 1;
	public static final int T_OP_PILHA = 2;
	public static final int T_PILHA_PILHA = 3;

	private PilhaSemantica pilhaSemantica;
	private StringBuffer fonte;
	private StringBuffer fonteParaDebug;
	private StringBuffer fonteRodape;
	private Lexico lexico;
	private int linhaAtual = 0;
	private int labelAtual = 0;
	private int cadeiaAtual = 0;
	private StringBuffer linhaPendente;
	private int tipoDefault = T_SEM_TIPO;

	/* vari�veis p�blicas de estado */
	private int tipoSendoDeclarado;
	private int tipoFuncaoSendoDeclarada;
	private int classeSendoDeclarada;
	private String contextoAtual;
	private String funcaoDeclarandoAtualmente;
	private int tamanhoVariaveis;
	private int deslocamentoProximoParametro;
	private int deslocamentoProximaLocal;
	private int deslocamentoProximaGlobal;
	private PilhaEstrutura pilhaEstrutura = new PilhaEstrutura();
	// private String labelInicioEnquanto, labelFimEnquanto; // Falta vetorizar
	// para compreender varios niveis

	private String nomeFonte;
	private String nomePackage;

	private String cadeia;

	private Vector<SimboloTabela> tabelaSimbolos;

	private Hashtable<String, NodoRotulo> listaRotulos;

	
	public Semantico(Lexico lexico) {

		this.lexico = lexico;
		pilhaSemantica = new PilhaSemantica();

		tabelaSimbolos = new Vector<SimboloTabela>();

		listaRotulos = new Hashtable<String, NodoRotulo>();
		
		fonte = new StringBuffer();
		fonteRodape = new StringBuffer();
		fonteParaDebug = new StringBuffer();

		fonteRodape.append("\n\nC0:\n\t\"          \"");
		linhaPendente = new StringBuffer();

	}

	public void acaoSemantica(int regra) {

		if (regra != 1000) {
			linhaAtual = lexico.getLinha();
		}

		switch (regra) {
		case 0:
			criaAsm();
			cadeia = "criaAsm()";
			break;
		case 2:
			somaTamanhosGlobais();
			cadeia = "somaTamanhosGlobais()";
			break;
		case 3:
			invocaProcedimentoPrincipal();
			cadeia = "invocaProcedimentoPrincipal()";
			break;
		case 11:
			debuga(11);
			cadeia = "debuga()";
			break;
		case 20:
			inicioAreaFuncoes();
			cadeia = "inicioAreaFuncoes()";
			break;
		case 25:
			finalizaDeclaracaoFuncao();
			cadeia = "finalizaDeclaracaoFuncao()";
			break;
		case 32:
			somaTamanhosLocais();
			cadeia = "somaTamanhosLocais()";
			break;
		case 33:
			armazenaEstadoMemoria();
			cadeia = "armazenaEstadoMemoria()";
			break;
		case 40:
			trataDeclaracaoGlobal();
			cadeia = "trataDeclaracaoGlobal()";
			break;
		case 45:
			trataDeclaracaoLocal();
			cadeia = "trataDeclaracaoLocal()";
			break;
		case 47:
			trataDeclaracaoIdFuncao();
			cadeia = "trataDeclaracaoIdFuncao()";
			break;
		case 48:
			trataDeclaracaoIdPrototipo();
			cadeia = "trataDeclaracaoIdPrototipo()";
			break;
		case 51:
			alimentaTSComParametros();
			cadeia = "alimentaTSComParametros()";
			break;
		case 53:
			alimentaTSPorPrototipo();
			cadeia = "alimentaTSPorPrototipo()";
			break;
		// case 56 : declaraIdentificador(true);cadeia =
		// "declaraIdentificador(true)"; break;
		case 63:
			declaraConstante();
			cadeia = "declaraConstante()";
			break;
		case 64:
			acumulaTamanhoVariaveis();
			cadeia = "acumulaTamanhoVariaveis()";
			break;
		case 65:
			declaraIdentificador();
			cadeia = "declaraIdentificador()";
			break;
		case 68:
			declaraVetor();
			cadeia = "declaraVetor()";
			break;
		case 73:
			realizaAtribuicaoConstante();
			cadeia = "realizaAtribuicaoConstante()";
			break;
		case 75:
			declaraParametro();
			cadeia = "declaraParametro()";
			break;
		case 100:
			empilhaPosicaoLeitura();
			cadeia = "empilhaPosicaoLeitura()";
			break;
		case 101:
			implementaLeitura();
			cadeia = "implementaLeitura()";
			break;
		case 102:
			empilhaPosicaoEscrita();
			cadeia = "empilhaPosicaoEscrita()";
			break;
		case 103:
			empilhaPosicaoEscritaPorIdentificador();
			cadeia = "empilhaPosicaoEscritaPorIdentificador()";
			break;
		case 104:
			implementaEscritaComPosicao();
			cadeia = "implementaEscritaComPosicao()";
			break;
		case 105:
			implementaEscrita();
			cadeia = "implementaEscrita()";
			break;
		case 106:
			empilhaPosicaoRelativaEscrita();
			cadeia = "empilhaPosicaoRelativaEscrita()";
			break;
		case 107:
			implementaConversaoParaCaracter();
			cadeia = "implementaConversaoParaCaracter()";
			break;
		case 110:
			implementaConversaoParaInteiro();
			cadeia = "implementaConversaoParaInteiro()";
			break;
		case 111:
			realizaAtribuicao();
			cadeia = "realizaAtribuicao()";
			break;
		case 112:
			realizaAtribuicaoParaVetor();
			cadeia = "realizaAtribuicaoParaVetor()";
			break;
		case 119:
			constroiInicioSenao();
			cadeia = "constroiInicioSenao()";
			break;
		case 120:
			constroiFimSe();
			cadeia = "constroiFimSe()";
			break;
		case 121:
			constroiCondicaoSe();
			cadeia = "constroiCondicaoSe()";
			break;
		case 123:
			constroiInicioEnquanto();
			cadeia = "constroiInicioEnquanto()";
			break;
		case 124:
			constroiCondicaoEnquanto();
			cadeia = "constroiCondicaoEnquanto()";
			break;
		case 125:
			constroiFimEnquanto();
			cadeia = "constroiFimEnquanto()";
			break;
		case 130:
			realizaAtribuicaoPara();
			cadeia = "realizaAtribuicaoPara()";
			break;
		case 131:
			constroiInicioLacoPara();
			cadeia = "constroiInicioLacoPara()";
			break;
		case 132:
			constroiCondicaoPara();
			cadeia = "constroiCondicaoPara()";
			break;
		case 133:
			realizaAtribuicaoLacoPara();
			cadeia = "realizaAtribuicaoLacoPara()";
			break;
		case 134:
			constroiFimPara();
			cadeia = "constroiFimPara()";
			break;
		case 135:
			constroiInicioRepita();
			cadeia = "constroiInicioRepita()";
			break;
		case 136:
			constroiCondicaoRepitaAte();
			cadeia = "constroiCondicaoRepitaAte()";
			break;
		case 137:
			constroiCondicaoRepitaEnquanto();
			cadeia = "constroiCondicaoRepitaEnquanto()";
			break;
		case 140:
			constroiPrimeiraClausulaCaso();
			cadeia = "constroiPrimeiraClausulaCaso()";
			break;
		case 141:
			constroiInicioClausulasSeguintesCaso();
			cadeia = "constroiInicioClausulasSeguintesCaso()";
			break;
		case 142:
			constroiFimCaso();
			cadeia = "constroiFimCaso()";
			break;
		case 143:
			constroiSaltoParaFimDoCaso();
			cadeia = "constroiSaltoParaFimDoCaso()";
			break;
		case 144:
			constroiClausulasSenaoCaso();
			cadeia = "constroiClausulasSenaoCaso()";
			break;
		case 155:
			estabeleceRotulo();
			cadeia = "estabeleceRotulo()";
			break;
		case 160:
			implementaVaPara();
			cadeia = "implementaVaPara()";
			break;			
		case 180:
			invocaApagaTela();
			cadeia = "invocaApagaTela()";
			break;
		case 190:
			realizaRetornoDeFuncao();
			cadeia = "realizaRetornoDeFuncao()";
			break;
		case 205:
			expressao();
			cadeia = "expressao()";
			break; // expressao :- termo_logico ou termo_logico
		case 210:
			termoLogico();
			cadeia = "termoLogico()";
			break; // termo_logico :- fator_logico e fator_logico
		case 212:
			comparaIgualdades("BEQ", 212);
			cadeia = "comparaIgualdades( BEQ, 212 )";
			break; // fator_logico :- rel_igualdade == rel_igualdade
		case 213:
			comparaIgualdades("BNE", 213);
			cadeia = "comparaIgualdades( BNE, 213 )";
			break; // fator_logico :- rel_igualdade != rel_igualdade
		case 220:
			comparaExpressoes("BGT", 220);
			cadeia = "comparaExpressoes( BGT, 220 )";
			break; // fator_logico :- expr_simples > expr_simples
		case 221:
			comparaExpressoes("BLT", 221);
			cadeia = "comparaExpressoes( BLT, 221 )";
			break; // fator_logico :- expr_simples < expr_simples
		case 222:
			comparaExpressoes("BGE", 222);
			cadeia = "comparaExpressoes( BGE, 222 )";
			break; // fator_logico :- expr_simples >= expr_simples
		case 223:
			comparaExpressoes("BLE", 223);
			cadeia = "comparaExpressoes( BLE, 223 )";
			break; // fator_logico :- expr_simples <= expr_simples
		case 227:
			somaTermos();
			cadeia = "somaTermos()";
			break; // expressao_simples :- termo + termo
		case 229:
			subtraiTermos();
			cadeia = "subtraiTermos()";
			break; // expressao_simples :- termo - termo
		case 232:
			multiplicaUnarios();
			cadeia = "multiplicaUnarios()";
			break; // termo :- unario * unario
		case 234:
			divideUnarios();
			cadeia = "divideUnarios()";
			break; // termo :- unario / unario
		case 240:
			negativaFator();
			cadeia = "negativaFator()";
			break; // unario :- - fator
		case 245:
			negaFator();
			cadeia = "negaFator()";
			break; // unario :- negue fator
		case 255:
			empilhaFatorInteiro();
			cadeia = "empilhaFatorInteiro()";
			break;
		case 265:
			empilhaFatorCaracter();
			cadeia = "empilhaFatorCaracter()";
			break;
		case 270:
			empilhaFatorLogico();
			cadeia = "empilhaFatorLogico()";
			break;
		case 300:
			marcaInicioArgumentos();
			cadeia = "marcaInicioArgumentos()";
			break;
		case 301:
			realizaChamadaFuncao();
			cadeia = "realizaChamadaFuncao()";
			break;
		case 380:
			resolveReferenciaIdAtribuicao();
			cadeia = "resolveReferenciaIdAtribuicao()";
			break;
		case 382:
			resolveReferenciaIdAtribuicaoVetor();
			cadeia = "resolveReferenciaIdAtribuicaoVetor()";
			break;
		case 400:
			resolveReferenciaId();
			cadeia = "resolveReferenciaId()";
			break;
		case 404:
			resolveReferenciaIdVetor();
			cadeia = "resolveReferenciaIdVetor()";
			break;
		case 406:
			resolveReferenciaChamadaFuncao();
			cadeia = "resolveReferenciaChamadaFuncao()";
			break;
		case 410:
			defineTipoSendoDeclarado(410);
			cadeia = "defineTipoSendoDeclarado( 410 )";
			break;
		case 412:
			defineTipoSendoDeclarado(412);
			cadeia = "defineTipoSendoDeclarado( 412 )";
			break;
		case 413:
			defineTipoSendoDeclarado(413);
			cadeia = "defineTipoSendoDeclarado( 413 )";
			break;
		case 414:
			defineTipoSendoDeclarado(414);
			cadeia = "defineTipoSendoDeclarado( 414 )";
			break;
		case 465:
			identificador();
			cadeia = "identificador()";
			break;
		case 900:
			agregaRodape();
			cadeia = "agregaRodape()";
			break;
		case 999:
			exibeMensagemTabelaSimbolos();
			cadeia = "exibeMensagemTabelaSimbolos()";
			break;
		default:
			naoFazNada();

		}
		Verto.getInstance().setUltimaAcaoSemantica(cadeia);
		

	}

	private void debuga( int i ) {
		if ( i == 11 )
			fonte.append(formataMacro(null, "NOP", "", "--------------------------------Debug----------------------------------" ));
	}

	protected String getCurrentlyExecutingMethodName() {
		Throwable t = new Throwable();
		StackTraceElement[] elements = t.getStackTrace();
		if (elements.length <= 0)
			return "[No Stack Information Available]";
		// elements[0] is this method
		if (elements.length < 2)
			return null;
		return elements[elements.length - 3].getMethodName();
	}

	private void naoFazNada() {
	}

	/* regra 0 */
	private void criaAsm() {

		exibeMensagemSemantico(" ");
		classeSendoDeclarada = SimboloTabela.T_GLOBAL;
		contextoAtual = "GLOBAL";
		deslocamentoProximaGlobal = 0;
		labelAtual = 0;

		fonte.append("; TESTE.ASM\n");
		fonte.append(formataMacro(null, "MOV", "65400, R6",
				"Inicializa ponteiro da Pilha"));
		tamanhoVariaveis = 0;
	}

	/* regra 2 */
	private void somaTamanhosGlobais() {

		fonte.append(formataMacro(null, "SUB", tamanhoVariaveis + ", R6",
				"Reserva espa�o para vari�veis globais"));
		tamanhoVariaveis = 0;
	}

	/* regra 3 */
	private void invocaProcedimentoPrincipal() {

		fonte.append(formataMacro(null, "JSR", "PRINCIPAL",
				"Chama rotina principal"));
		fonte.append(formataMacro(null, "HLT", " ", "Encerra execu��o"));
		exibeMensagemSemantico("-----------------------------------------------------------------------------AMBIENTE GLOBAL");

	}

	/* regra 20 */
	private void inicioAreaFuncoes() {

		classeSendoDeclarada = SimboloTabela.T_LOCAL;
	}

	/* regra 25 */
	private void finalizaDeclaracaoFuncao() {

		desativaLocaisTabelaSimbolos(contextoAtual);
		exibeMensagemSemantico("Restauro estado da m�quina");
		exibeMensagemSemantico("Desativei na TS as variaveis locais do contexto: "
				+ contextoAtual);
		exibeMensagemSemantico("-----------------------------------------------------------------------------"
				+ contextoAtual);
		fonte.append("\n");
		fonte.append("#FIM_");
		fonte.append(contextoAtual);
		fonte.append(":\n");
		fonte.append(formataMacro(null, "POP", "R4",
				"Restauro estado da m�quina"));
		fonte.append(formataMacro(null, "POP", "R3",
				"Restauro estado da m�quina"));
		fonte.append(formataMacro(null, "POP", "R2",
				"Restauro estado da m�quina"));
		fonte.append(formataMacro(null, "POP", "R1",
				"Restauro estado da m�quina"));
		fonte.append(formataMacro(null, "POP", "R0",
				"Restauro estado da m�quina"));
		if (tamanhoVariaveis > 0) {
			fonte.append(formataMacro(null, "ADD", tamanhoVariaveis + ", R6",
					"Desaloca espa�o de vari�veis locais"));
		}
		fonte.append(formataMacro(null, "POP", "R5",
				"Restaura o Base Pointer da Fun��o chamadora"));
		fonte.append("\tRTS\n");
		tamanhoVariaveis = 0;
	}

	/* regra 32 */
	private void somaTamanhosLocais() {

		fonte.append(formataMacro(null, "SUB", tamanhoVariaveis + ", R6",
				"Reservo espa�o na pilha para variaveis locais"));
	}

	/* regra 33 */
	private void armazenaEstadoMemoria() {

		exibeMensagemSemantico("Armazeno estado da m�quina");
		fonte.append(formataMacro(null, "PUSH", "R0",
				"Salvo estado da m�quina no momento da chamada"));
		fonte.append(formataMacro(null, "PUSH", "R1",
				"Salvo estado da m�quina no momento da chamada"));
		fonte.append(formataMacro(null, "PUSH", "R2",
				"Salvo estado da m�quina no momento da chamada"));
		fonte.append(formataMacro(null, "PUSH", "R3",
				"Salvo estado da m�quina no momento da chamada"));
		fonte.append(formataMacro(null, "PUSH", "R4",
				"Salvo estado da m�quina no momento da chamada\n"));
	}

	/* regra 40 */
	private void trataDeclaracaoGlobal() {

	}

	/* regra 45 */
	private void trataDeclaracaoLocal() {

	}

	/* regra 47 */
	private void trataDeclaracaoIdFuncao() {

		NodoPilhaSemantica nodoPilha;

		tipoFuncaoSendoDeclarada = tipoSendoDeclarado;

		nodoPilha = pilhaSemantica.pop();

		pilhaSemantica.push(nodoPilha.getCodigo().toUpperCase(),
				tipoFuncaoSendoDeclarada, 47);
		exibeMensagemSemantico("Empilhei nome da fun��o: "
				+ nodoPilha.getCodigo().toUpperCase());

		funcaoDeclarandoAtualmente = nodoPilha.getCodigo().toUpperCase();

		pilhaSemantica.push("#parametros#", Lexico.T_DESCONHECIDO, 47);
		exibeMensagemSemantico("Empilhei marcador: #parametros#");

		fonte.append("\n");
		contextoAtual = lexico.getUltimoLexema().toUpperCase();
		fonte.append(contextoAtual + ":\n");
		fonte.append(formataMacro(null, "PUSH", "R5",
				"Preservo o Base Pointer da fun��o chamadora"));
		fonte.append(formataMacro(null, "MOV", "R6, R5  ",
				"Copio endere�o/pilha do Base Pointer (inicio-locais)"));

		/* Inicializo pontos de refer�ncia para par�metros e vari�veis locais */
		deslocamentoProximoParametro = 4;
		deslocamentoProximaLocal = 0;
	}

	/* regra 48 */
	private void trataDeclaracaoIdPrototipo() {

		NodoPilhaSemantica nodoPilha;

		tipoFuncaoSendoDeclarada = tipoSendoDeclarado;

		nodoPilha = pilhaSemantica.pop();

		pilhaSemantica.push(nodoPilha.getCodigo().toUpperCase(),
				tipoFuncaoSendoDeclarada, 48);
		exibeMensagemSemantico("Empilhei nome do prot�tipo de fun��o: "
				+ nodoPilha.getCodigo().toUpperCase());

		funcaoDeclarandoAtualmente = nodoPilha.getCodigo().toUpperCase();

		pilhaSemantica.push("#parametros#", Lexico.T_DESCONHECIDO, 47);
		exibeMensagemSemantico("Empilhei marcador: #parametros#");

		contextoAtual = lexico.getUltimoLexema().toUpperCase();
	}

	/* regra 51 */
	private void alimentaTSComParametros() {

		LinkedList filaAuxiliar = new LinkedList();
		NodoPilhaSemantica parametro;
		boolean continua = true;
		NodoPilhaSemantica nodoPilha;
		int i = 0;
		int[] tiposParametros;

		do {
			parametro = pilhaSemantica.pop();

			if (parametro.getCodigo().equals("#parametros#")) {
				exibeMensagemSemantico("Desempilhei marcador: "
						+ parametro.getCodigo());
				continua = false;
			} else {
				i++;
				exibeMensagemSemantico("Desempilhei parametro: "
						+ parametro.getCodigo());
				filaAuxiliar.addLast(parametro);
			}
		} while (continua);

		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei nome da fun��o: "
				+ nodoPilha.getCodigo());

		tiposParametros = new int[i];

		if (filaAuxiliar.isEmpty()) {
			exibeMensagemSemantico("Procedimento sem parametros");
			alimentaFuncaoTabelaSimbolos(nodoPilha.getCodigo(), true,
					tiposParametros);
		} else {
			i = tiposParametros.length - 1;
			while (!filaAuxiliar.isEmpty()) {

				parametro = (NodoPilhaSemantica) filaAuxiliar.removeFirst();
				alimentaParametroTabelaSimbolos(parametro.getCodigo(),
						parametro.getTipoAssociado(),
						deslocamentoProximoParametro);
				deslocamentoProximoParametro += tamanhoTipo(parametro
						.getTipoAssociado());
				tiposParametros[i] = parametro.getTipoAssociado();
				i--;
			}
			exibeMensagemSemantico("Endere�os dos parametros calculados");
			alimentaFuncaoTabelaSimbolos(nodoPilha.getCodigo(), true,
					tiposParametros);
		}

	}

	/* regra 53 */
	private void alimentaTSPorPrototipo() {

		LinkedList filaAuxiliar = new LinkedList();
		NodoPilhaSemantica parametro;
		boolean continua = true;
		NodoPilhaSemantica nodoPilha;
		int i = 0;
		int[] tiposParametros;

		do {
			parametro = pilhaSemantica.pop();

			if (parametro.getCodigo().equals("#parametros#")) {
				exibeMensagemSemantico("Desempilhei marcador: "
						+ parametro.getCodigo());
				continua = false;
			} else {
				i++;
				exibeMensagemSemantico("Desempilhei parametro: "
						+ parametro.getCodigo());
				filaAuxiliar.addLast(parametro);
			}
		} while (continua);

		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei nome da fun��o: "
				+ nodoPilha.getCodigo());

		tiposParametros = new int[i];

		if (filaAuxiliar.isEmpty()) {
			exibeMensagemSemantico("Procedimento sem parametros");
			alimentaPrototipoTabelaSimbolos(nodoPilha.getCodigo(), true,
					tiposParametros);
		} else {
			i = tiposParametros.length - 1;
			while (!filaAuxiliar.isEmpty()) {

				parametro = (NodoPilhaSemantica) filaAuxiliar.removeFirst();
				deslocamentoProximoParametro += tamanhoTipo(parametro
						.getTipoAssociado());
				tiposParametros[i] = parametro.getTipoAssociado();
				i--;
			}
			exibeMensagemSemantico("Endere�os dos parametros calculados");
			alimentaPrototipoTabelaSimbolos(nodoPilha.getCodigo(), true,
					tiposParametros);
		}

	}

	// /* regra 56 */
	// private void declaraConstante(){
	// pilhaSemantica.push( lexico.getUltimoLexema(), Lexico.T_CONSTANTE, 56 );
	// }

	/* regra 64 */
	private void acumulaTamanhoVariaveis() {

		tamanhoVariaveis += tamanhoTipo(tipoSendoDeclarado);
	}

	/* regra 65 */
	private void declaraIdentificador() {

		NodoPilhaSemantica nodoPilha;

		String identificadorADeclarar;

		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei identificador declarado: "
				+ nodoPilha.getCodigo());

		identificadorADeclarar = nodoPilha.getCodigo();
		exibeMensagemSemantico("Declaro identificador: "
				+ nodoPilha.getCodigo());

		if (classeSendoDeclarada == SimboloTabela.T_GLOBAL) {
			alimentaGlobalTabelaSimbolos(identificadorADeclarar,
					(65398 + deslocamentoProximaGlobal), false, false);
			deslocamentoProximaGlobal = deslocamentoProximaGlobal
					- tamanhoTipo(tipoSendoDeclarado);
		} else {
			deslocamentoProximaLocal = deslocamentoProximaLocal
					- tamanhoTipo(tipoSendoDeclarado);
			alimentaLocalTabelaSimbolos(identificadorADeclarar,
					deslocamentoProximaLocal, false, false);
		}
	}

	/* regra 66 */
	private void declaraConstante() {

		NodoPilhaSemantica nodoPilha;

		String identificadorADeclarar;

		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei identificador declarado: "
				+ nodoPilha.getCodigo());

		identificadorADeclarar = nodoPilha.getCodigo();
		exibeMensagemSemantico("Declaro identificador: "
				+ nodoPilha.getCodigo());

		if (classeSendoDeclarada == SimboloTabela.T_GLOBAL) {
			alimentaGlobalTabelaSimbolos(identificadorADeclarar,
					(65398 + deslocamentoProximaGlobal), true, false);
			deslocamentoProximaGlobal = deslocamentoProximaGlobal
					- tamanhoTipo(tipoSendoDeclarado);
		} else {
			deslocamentoProximaLocal = deslocamentoProximaLocal
					- tamanhoTipo(tipoSendoDeclarado);
			alimentaLocalTabelaSimbolos(identificadorADeclarar,
					deslocamentoProximaLocal, true, false);
		}
		
		pilhaSemantica.push( nodoPilha.getCodigo(), tipoSendoDeclarado, 66 );

	}

	/* regra 67 */
	private void realizaAtribuicaoConstante() {

		NodoPilhaSemantica ladoDireito, ladoEsquerdo;
		int tipoLadoDireito, tipoLadoEsquerdo;
		String descricaoLadoDireito, descricaoLadoEsquerdo;

		ladoDireito = pilhaSemantica.pop();
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);
		ladoEsquerdo = pilhaSemantica.pop();
		tipoLadoEsquerdo = ladoEsquerdo.getTipoAssociado();
		descricaoLadoEsquerdo = ladoEsquerdo.getCodigo();
		exibeMensagemSemantico("Desempilhei identificador ("
				+ traduzAliasTipo(tipoLadoEsquerdo) + "): "
				+ descricaoLadoEsquerdo);
		
		System.out.println( "Ricardo 1 = " + descricaoLadoEsquerdo );

		if (tipoLadoEsquerdo != tipoLadoDireito) {
			throw new ErroSemanticoException(
					"Tipos incompat�veis na atribui��o. Vari�vel do tipo: '"
							+ ladoEsquerdo.getDescricaoTipo()
							+ "' recebendo express�o do tipo: '"
							+ ladoDireito.getDescricaoTipo() + "'.");
		} else {
			if (tipoLadoDireito == Lexico.T_CARACTER) {

				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {

					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					if (descricaoLadoEsquerdo.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoEsquerdo + ", R1",
								"Movo destino para R1"));
					}
				} else {

					if (descricaoLadoDireito.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoDireito, "R0");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoDireito + ", R0",
								"Movo origem para R0"));
					}

					if (descricaoLadoEsquerdo.contains("R5")) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoEsquerdo + ", R1",
								"Movo destino para R1"));
					}
				}

				fonte.append(formataMacro(null, "JSR", "#CPSTR",
						"Copia uma string"));
			} else {
				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					fonte.append(formataMacro(null, "MOV", "R0, "
							+ descricaoLadoEsquerdo, "Efetuo atribui��o"));
				} else {
					fonte
							.append(formataMacro(null, "MOV",
									descricaoLadoDireito + ", "
											+ descricaoLadoEsquerdo,
									"Efetuo atribui��o"));
				}
			}
		}
	}

	/* regra 68 */
	private void declaraVetor() {

		NodoPilhaSemantica nodoPilha;

		String identificadorADeclarar;
		int    dimensaoVetor;
		
		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei dimens�o do vetor: "
				+ nodoPilha.getCodigo());

		dimensaoVetor = Integer.parseInt( nodoPilha.getCodigo() );
		
		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei identificador declarado: "
				+ nodoPilha.getCodigo());

		identificadorADeclarar = nodoPilha.getCodigo();
		exibeMensagemSemantico("Declaro identificador: "
				+ nodoPilha.getCodigo());

		if (classeSendoDeclarada == SimboloTabela.T_GLOBAL) {
			alimentaGlobalTabelaSimbolos(identificadorADeclarar,
					(65398 + deslocamentoProximaGlobal), false, true);
			deslocamentoProximaGlobal = deslocamentoProximaGlobal
					- ( dimensaoVetor * tamanhoTipo(tipoSendoDeclarado) );
		} else {
			deslocamentoProximaLocal = deslocamentoProximaLocal
					- ( dimensaoVetor * tamanhoTipo(tipoSendoDeclarado) );
			alimentaLocalTabelaSimbolos(identificadorADeclarar,
					deslocamentoProximaLocal, false, true);
		}
	}
	
	/* regra 75 */
	private void declaraParametro() {

		NodoPilhaSemantica nodoPilha;

		nodoPilha = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei identificador: "
				+ nodoPilha.getCodigo());

		nodoPilha.setTipoAssociado(tipoSendoDeclarado);
		nodoPilha.setRegraQueEmpilhou(75);

		pilhaSemantica.push(nodoPilha);
		exibeMensagemSemantico("Empilhei parametro declarado: "
				+ nodoPilha.getCodigo());

	}

	/* regra 100 */
	private void empilhaPosicaoLeitura() {

		pilhaSemantica.push(lexico.getUltimoLexema(), Lexico.T_INTEIRO, 100);
		exibeMensagemSemantico("Empilhei posi��o leitura: "
				+ lexico.getUltimoLexema());
	}

	/* regra 101 */
	private void implementaLeitura() {

		NodoPilhaSemantica posicao, conteudo;
		int tipoConteudo;
		String descricaoConteudo;

		conteudo = pilhaSemantica.pop();
		popDeVetor( conteudo );
		tipoConteudo = conteudo.getTipoAssociado();
		descricaoConteudo = conteudo.getCodigo();
		exibeMensagemSemantico("Desempilhei identificador ("
				+ traduzAliasTipo(tipoConteudo) + "): " + descricaoConteudo);

		posicao = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei posi��o de leitura: " + posicao);

		/** Aqui preciso testar como na atribui��o */
		if (tipoConteudo == Lexico.T_CARACTER) {

			fonte.append(formataMacro(null, "MOV", descricaoConteudo + ", R0",
					"Movimento �rea para receber leitura"));
			fonte.append(formataMacro(null, "MOV",
					posicao.getCodigo() + ", R1",
					"Move a posi��o inicial para ler para R1"));
			fonte.append(formataMacro(null, "MOV", "29, R2",
					"move para R2, o tamanho da �rea de leitura m�xima"));
			fonte.append(formataMacro(null, "JSR", "#GETS",
					"Chamo rotina de leitura"));
		} else {
			if (tipoConteudo == Lexico.T_INTEIRO) {

				fonte.append(formataMacro(null, "SUB", "2, R6",
								"Reservo 2 bytes na pilha para ler inteiro como caracter"));
				fonte.append(formataMacro(null, "MOV", "R6, R0",
						"Movimento �rea para receber leitura"));
				fonte.append(formataMacro(null, "MOV", posicao.getCodigo()
						+ ", R1", "Move a posi��o inicial para ler para R1"));
				fonte.append(formataMacro(null, "MOV", "29, R2",
						"move para R2, o tamanho da �rea de leitura m�xima"));
				fonte.append(formataMacro(null, "JSR", "#GETS",
						"Chamo rotina de leitura"));
				fonte.append(formataMacro(null, "MOV", "R6, R0",
						"Movimento express�o a escrever para R0"));
				fonte.append(formataMacro(null, "JSR", "#ATOI",
						"Converte de cadeia de caracteres para inteiro"));
				fonte.append(formataMacro(null, "MOV", "R0, "
						+ descricaoConteudo, "Atribuo R0 � vari�vel"));
				fonte
						.append(formataMacro(null, "ADD", "2, R6",
								"Desaloco na pilha espa�o da vari�vel caracter tempor�ria"));
			} else {
				throw new ErroSemanticoException(
						"Identificador do tipo caracter era esperado: "
								+ conteudo.getDescricaoTipo() + ".");
			}
		}
	}

	/* regra 102 */
	private void empilhaPosicaoEscrita() {

		pilhaSemantica.push(lexico.getUltimoLexema(), Lexico.T_INTEIRO, 102);
		exibeMensagemSemantico("Empilhei posi��o escrita: "
				+ lexico.getUltimoLexema());
	}

	/* regra 103 */
	private void empilhaPosicaoEscritaPorIdentificador() {
		exibeMensagemSemantico("Mantive endere�o da variavel na pilha semantica.");
	}

	/* regra 104 */
	private void implementaEscritaComPosicao() {

		NodoPilhaSemantica posicao, conteudo;
		int tipoConteudo;
		String descricaoConteudo;

		conteudo = pilhaSemantica.pop();
		popDeVetor( conteudo );
		tipoConteudo = conteudo.getTipoAssociado();
		descricaoConteudo = conteudo.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoConteudo) + "): " + descricaoConteudo);

		posicao = pilhaSemantica.pop();
		exibeMensagemSemantico("Desempilhei posi��o de escrita: " + posicao);

		if (tipoConteudo == Lexico.T_INTEIRO) {

			if (conteudo.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho resultado da express�o"));
			} else {
				fonte.append(formataMacro(null, "MOV", descricaoConteudo
						+ ", R0", "Movimento express�o a escrever para R0"));
			}
			fonte
					.append(formataMacro(null, "MOV", "C0, R1",
							"move para R1, o endere�o da posi��o onde a variavel ser� convertida"));
			fonte.append(formataMacro(null, "JSR", "#ITOA",
					"Converte de inteiro para cadeia de caracteres"));
			fonte.append(formataMacro(null, "MOV", "C0, R0",
					"Move o endere�o do que se quer escrever"));
			fonte.append(formataMacro(null, "MOV",
					posicao.getCodigo() + ", R1",
					"Move a posi��o inicial para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		} else if (tipoConteudo == Lexico.T_CARACTER) {

			if (conteudo.getCodigo().indexOf("[R5") >= 0) {
				resolveReferencia(conteudo.getCodigo(), "R0");
			} else {
				fonte.append(formataMacro(null, "MOV", conteudo.getCodigo()
						+ ", R0", "Move o endere�o do que se quer escrever"));
			}

			fonte.append(formataMacro(null, "MOV",
					posicao.getCodigo() + ", R1",
					"Move a posi��o inicial para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		} else {
			fonte.append(formataMacro(null, "MOV", conteudo.getCodigo()
					+ ", R0", "Move o endere�o do que se quer escrever"));
			fonte.append(formataMacro(null, "MOV",
					posicao.getCodigo() + ", R1",
					"Move a posi��o inicial para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		}
	}

	/* regra 105 */
	private void implementaEscrita() {

		NodoPilhaSemantica conteudo;
		int tipoConteudo;
		String descricaoConteudo;

		conteudo = pilhaSemantica.pop();
		popDeVetor( conteudo );
		tipoConteudo = conteudo.getTipoAssociado();
		descricaoConteudo = conteudo.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoConteudo) + "): " + descricaoConteudo);

		if (tipoConteudo == Lexico.T_INTEIRO) {

			if (conteudo.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho resultado da express�o"));
			} else {
				fonte.append(formataMacro(null, "MOV", descricaoConteudo
						+ ", R0", "Movimento express�o a escrever para R0"));
			}
			fonte
					.append(formataMacro(null, "MOV", "C0, R1",
							"move para R1, o endere�o da posi��o onde a variavel ser� convertida"));
			fonte.append(formataMacro(null, "JSR", "#ITOA",
					"Converte de inteiro para cadeia de caracteres"));
			fonte.append(formataMacro(null, "MOV", "C0, R0",
					"Move o endere�o do que se quer escrever"));
			fonte.append(formataMacro(null, "MOV", "1, R1",
					"Move a posi��o inicial default (1) para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		} else if (tipoConteudo == Lexico.T_CARACTER) {

			if (conteudo.getCodigo().indexOf("[R5") >= 0) {
				resolveReferencia(conteudo.getCodigo(), "R0");
			} else {
				fonte.append(formataMacro(null, "MOV", conteudo.getCodigo()
						+ ", R0", "Move o endere�o do que se quer escrever"));
			}

			fonte.append(formataMacro(null, "MOV", "1, R1",
					"Move a posi��o inicial default (1) para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		} else {
			fonte.append(formataMacro(null, "MOV", conteudo.getCodigo()
					+ ", R0", "Move o endere�o do que se quer escrever"));
			fonte.append(formataMacro(null, "MOV", "1, R1",
					"Move a posi��o inicial default (1) para escrever"));
			fonte.append(formataMacro(null, "JSR", "#EXIBE", "Exibe"));
		}
	}

	/* regra 106 */
	private void empilhaPosicaoRelativaEscrita() {

		pilhaSemantica.push(Integer
				.toString(lexico.getUltimoLexema().length() + 2),
				Lexico.T_INTEIRO, 100);
		exibeMensagemSemantico("Empilhei posi��o leitura: "
				+ lexico.getUltimoLexema());
	}

	/* regra 107 */
	private void implementaConversaoParaCaracter() {

		NodoPilhaSemantica posicao, conteudo;
		int tipoConteudo;
		String descricaoConteudo;

		conteudo = pilhaSemantica.pop();
		tipoConteudo = conteudo.getTipoAssociado();
		descricaoConteudo = conteudo.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoConteudo) + "): " + descricaoConteudo);

		if (tipoConteudo == Lexico.T_INTEIRO) {

			if (conteudo.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho resultado da express�o"));
			} else {
				fonte.append(formataMacro(null, "MOV", descricaoConteudo
						+ ", R0", "Movimento express�o a escrever para R0"));
			}
			fonte
					.append(formataMacro(null, "MOV", "C0, R1",
							"move para R1, o endere�o da posi��o onde a variavel ser� convertida"));
			fonte.append(formataMacro(null, "JSR", "#ITOA",
					"Converte de inteiro para cadeia de caracteres"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho resultado da convers�o de inteiro para string"));
			pilhaSemantica.push("$temp", Lexico.T_CARACTER, 107);
		} else {
			throw new ErroSemanticoException(
					"A express�o deve ser do tipo INTEIRO, mas � do tipo: "
							+ conteudo.getDescricaoTipo() + ".");
		}
	}

	/* regra 110 */
	private void implementaConversaoParaInteiro() {

		NodoPilhaSemantica posicao, conteudo;
		int tipoConteudo;
		String descricaoConteudo;

		conteudo = pilhaSemantica.pop();
		tipoConteudo = conteudo.getTipoAssociado();
		descricaoConteudo = conteudo.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoConteudo) + "): " + descricaoConteudo);

		if (tipoConteudo == Lexico.T_CARACTER) {

			if (conteudo.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho resultado da express�o"));
			} else {
				fonte.append(formataMacro(null, "MOV", descricaoConteudo
						+ ", R0", "Movimento express�o a escrever para R0"));
			}
			fonte.append(formataMacro(null, "JSR", "#ATOI",
					"Converte de cadeia de caracteres para inteiro"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho resultado da convers�o da string para inteiro"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 110);
		} else {
			throw new ErroSemanticoException(
					"A express�o deve ser do tipo CARACTER, mas � do tipo: "
							+ conteudo.getDescricaoTipo() + ".");
		}
	}

	/* regra 111 */
	private void realizaAtribuicao() {

		NodoPilhaSemantica ladoDireito, ladoEsquerdo;
		int tipoLadoDireito, tipoLadoEsquerdo;
		String descricaoLadoDireito, descricaoLadoEsquerdo;

		ladoDireito = pilhaSemantica.pop();
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);
		
		ladoEsquerdo = pilhaSemantica.pop();
		tipoLadoEsquerdo = ladoEsquerdo.getTipoAssociado();
		descricaoLadoEsquerdo = ladoEsquerdo.getCodigo();
		exibeMensagemSemantico("Desempilhei identificador ("
				+ traduzAliasTipo(tipoLadoEsquerdo) + "): "
				+ descricaoLadoEsquerdo);

		System.out.println( "Ricardo 1b = " + descricaoLadoEsquerdo );
		
		if (tipoLadoEsquerdo != tipoLadoDireito) {
			throw new ErroSemanticoException(
					"Tipos incompat�veis na atribui��o. Vari�vel do tipo: '"
							+ ladoEsquerdo.getDescricaoTipo()
							+ "' recebendo express�o do tipo: '"
							+ ladoDireito.getDescricaoTipo() + "'.");
		} else {
			if (tipoLadoDireito == Lexico.T_CARACTER) {

				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {

					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					if (descricaoLadoEsquerdo.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoEsquerdo + ", R1",
								"Movo destino para R1"));
					}
				} else {

					if (descricaoLadoDireito.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoDireito, "R0");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoDireito + ", R0",
								"Movo origem para R0"));
					}

					if (descricaoLadoEsquerdo.contains("R5")) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoEsquerdo + ", R1",
								"Movo destino para R1"));
					}
				}

				fonte.append(formataMacro(null, "JSR", "#CPSTR",
						"Copia uma string"));
			} else {
				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					fonte.append(formataMacro(null, "MOV", "R0, "
							+ descricaoLadoEsquerdo, "Efetuo atribui��o 1"));
				} else {
					fonte
							.append(formataMacro(null, "MOV",
									descricaoLadoDireito + ", "
											+ descricaoLadoEsquerdo,
									"Efetuo atribui��o 2"));
				}
			}
		}
	}

	private void resolveReferencia(String dsOrigem, String destino) {

		fonte.append(formataMacro(null, "MOV", "R5, " + destino,
				"Movo destino para " + destino));

		int p = dsOrigem.indexOf("R5+");
		if (p > 0) {
			int f = dsOrigem.indexOf("]", p + 1);
			fonte.append(formataMacro(null, "ADD", dsOrigem.substring(p + 3, f)
					+ ", " + destino, "adiciona endere�o variavel local"));
		} else {
			p = dsOrigem.indexOf("R5-");
			int f = dsOrigem.indexOf("]", p + 1);
			fonte.append(formataMacro(null, "SUB", dsOrigem.substring(p + 3, f)
					+ ", " + destino, "subtrai endere�o variavel local"));
		}
	}

	/* regra 112 */
	private void realizaAtribuicaoParaVetor() {

		NodoPilhaSemantica ladoDireito, ladoEsquerdo;
		int tipoLadoDireito, tipoLadoEsquerdo;
		String descricaoLadoDireito, descricaoLadoEsquerdo;

		ladoDireito = pilhaSemantica.pop(); 
		popDeVetor( ladoDireito );
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);
		
		ladoEsquerdo = pilhaSemantica.pop();
		tipoLadoEsquerdo = ladoEsquerdo.getTipoAssociado();
		descricaoLadoEsquerdo = ladoEsquerdo.getCodigo();
		exibeMensagemSemantico("Desempilhei identificador ("
				+ traduzAliasTipo(tipoLadoEsquerdo) + "): "
				+ descricaoLadoEsquerdo);

		System.out.println( "Ricardo 1c = " + descricaoLadoEsquerdo );
		
		if (tipoLadoEsquerdo != tipoLadoDireito) {
			throw new ErroSemanticoException(
					"Tipos incompat�veis na atribui��o. Vari�vel do tipo: '"
							+ ladoEsquerdo.getDescricaoTipo()
							+ "' recebendo express�o do tipo: '"
							+ ladoDireito.getDescricaoTipo() + "'.");
		} else {
			if (tipoLadoDireito == Lexico.T_CARACTER) {
				
				// Eskeff Aqui falta tratar a atribui�ao de strings

				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {

					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					if (descricaoLadoEsquerdo.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "POP","R1","Desempilho endere�o calculado do Vetor para R1"));
					}
				} else {

					if (descricaoLadoDireito.indexOf("R5") >= 0) {
						resolveReferencia(descricaoLadoDireito, "R0");
					} else {
						fonte.append(formataMacro(null, "MOV",
								descricaoLadoDireito + ", R0",
								"Movo origem para R0"));
					}

					if (descricaoLadoEsquerdo.contains("R5")) {
						resolveReferencia(descricaoLadoEsquerdo, "R1");
					} else {
						fonte.append(formataMacro(null, "POP","R1","Desempilho endere�o calculado do Vetor para R1"));
					}
				}

				fonte.append(formataMacro(null, "JSR", "#CPSTR",
						"Copia uma string"));
			} else {
				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho endere�o do vetor"));
					fonte.append(formataMacro(null, "MOV", "R0, [R1]", "Efetuo atribui��o 1"));
				} else {
					fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho endere�o do vetor"));
					fonte.append(formataMacro(null, "MOV", 
							     descricaoLadoDireito + ", [R1]", "Efetuo atribui��o 2"));
				}
			}
		}
	}

	private void popDeVetor(NodoPilhaSemantica nodo ) {
		if ( "[R4]".equals( nodo.getCodigo() ) ) {
			fonte.append(formataMacro(null, "POP", "R4", "Desempilho refer�ncia do vetor"));
		}
	}

	/* regra 119 */
	private void constroiInicioSenao() {

		NodoEstrutura nodoEstrutura;
		String labelFimEntao;
		String labelSenao;

		nodoEstrutura = pilhaEstrutura.pop();

		labelFimEntao = proximoLabel();
		nodoEstrutura.setLabel1(labelFimEntao);
		labelSenao = nodoEstrutura.getLabel2();

		fonte.append(formataMacro(null, "JMP", labelFimEntao,
				"Vai para o fim do verdadeiro: " + labelFimEntao));
		fonte.append(formataMacro(labelSenao, "NOP", "", "Inicio do Senao: "
				+ labelSenao));

		pilhaEstrutura.push(nodoEstrutura);
	}

	/* regra 120 */
	private void constroiFimSe() {

		NodoEstrutura nodoEstrutura;

		nodoEstrutura = pilhaEstrutura.pop();

		if (nodoEstrutura.getLabel1() == null) {
			fonte.append(formataMacro(nodoEstrutura.getLabel2(), "NOP", "",
					"fim do se: " + nodoEstrutura.getLabel2()));
		} else {
			fonte.append(formataMacro(nodoEstrutura.getLabel1(), "NOP", "",
					"fim do se: " + nodoEstrutura.getLabel1()));
		}
	}

	/* regra 121 */
	private void constroiCondicaoSe() {

		NodoPilhaSemantica nodoOp;
		NodoEstrutura nodoEstrutura;
		int tipoOp;
		String descricaoOp;
		String labelSenao;

		labelSenao = proximoLabel();
		nodoEstrutura = new NodoEstrutura(null, labelSenao, PilhaEstrutura.T_SE);
		pilhaEstrutura.push(nodoEstrutura);

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do if ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelSenao,
				"Se falso, vai para: " + labelSenao));

	}

	/* regra 123 */
	private void constroiInicioEnquanto() {

		NodoEstrutura nodoEstrutura;
		String labelInicioEnquanto;
		String labelFimEnquanto;

		labelInicioEnquanto = proximoLabel();
		labelFimEnquanto = proximoLabel();
		nodoEstrutura = new NodoEstrutura(labelInicioEnquanto,
				labelFimEnquanto, PilhaEstrutura.T_ENQUANTO);
		pilhaEstrutura.push(nodoEstrutura);

		fonte.append(formataMacro(labelInicioEnquanto, "NOP", "",
				"Inicio do Enquanto"));
	}

	/* regra 124 */
	private void constroiCondicaoEnquanto() {

		NodoEstrutura nodoEstrutura;
		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;
		String labelInicioEnquanto;
		String labelFimEnquanto;

		nodoEstrutura = pilhaEstrutura.pop();
		labelFimEnquanto = nodoEstrutura.getLabel2();

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do enquanto ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelFimEnquanto,
				"Se falso, vai para: " + labelFimEnquanto));

		pilhaEstrutura.push(nodoEstrutura);
	}

	/* regra 125 */
	private void constroiFimEnquanto() {

		NodoEstrutura nodoEstrutura;

		nodoEstrutura = pilhaEstrutura.pop();
		fonte.append(formataMacro(null, "JMP", nodoEstrutura.getLabel1(),
				"Volta a testar condi��o do enquanto: "
						+ nodoEstrutura.getLabel1()));
		fonte.append(formataMacro(nodoEstrutura.getLabel2(), "NOP", "",
				"fim do enquanto: " + nodoEstrutura.getLabel2()));
	}

	/* regra 130 */
	private void realizaAtribuicaoPara() {

		NodoPilhaSemantica ladoDireito, ladoEsquerdo;
		int tipoLadoDireito, tipoLadoEsquerdo;
		String descricaoLadoDireito, descricaoLadoEsquerdo;

		ladoDireito = pilhaSemantica.pop();
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);
		ladoEsquerdo = pilhaSemantica.pop();
		tipoLadoEsquerdo = ladoEsquerdo.getTipoAssociado();
		descricaoLadoEsquerdo = ladoEsquerdo.getCodigo();
		exibeMensagemSemantico("Desempilhei identificador ("
				+ traduzAliasTipo(tipoLadoEsquerdo) + "): "
				+ descricaoLadoEsquerdo);

		if (tipoLadoEsquerdo != Lexico.T_INTEIRO) {
			throw new ErroSemanticoException(
					"Tipos incompat�vel da vari�vel de la�o. Vari�vel do tipo: '"
							+ ladoEsquerdo.getDescricaoTipo() + "'.");
		} else {
			if (tipoLadoDireito != Lexico.T_INTEIRO) {
				throw new ErroSemanticoException(
						"Tipos incompat�veis na express�o inicial do para. Express�o do tipo: '"
								+ ladoDireito.getDescricaoTipo() + "'.");
			} else {
				if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
					fonte.append(formataMacro(null, "POP", "R0",
							"Desempilho resultado da express�o"));
					fonte.append(formataMacro(null, "MOV", "R0, "
							+ descricaoLadoEsquerdo, "Efetuo atribui��o"));
				} else {
					fonte
							.append(formataMacro(null, "MOV",
									descricaoLadoDireito + ", "
											+ descricaoLadoEsquerdo,
									"Efetuo atribui��o"));
				}
				pilhaSemantica.push(ladoEsquerdo); // Empilho variavel de
													// controle para ser usada
													// na atribui��o/incremento
				pilhaSemantica.push(ladoEsquerdo); // Empilho variavel de
													// controle para a
													// compara��o com a
													// express�o2
			}
		}
	}

	/* regra 131 */
	private void constroiInicioLacoPara() {

		NodoEstrutura nodoEstrutura;
		String labelInicioLacoPara;
		String labelFimLacoPara;

		labelInicioLacoPara = proximoLabel();
		labelFimLacoPara = proximoLabel();
		nodoEstrutura = new NodoEstrutura(labelInicioLacoPara,
				labelFimLacoPara, PilhaEstrutura.T_PARA);
		pilhaEstrutura.push(nodoEstrutura);

		fonte.append(formataMacro(labelInicioLacoPara, "NOP", "",
				"Inicio do La�o Para"));

	}

	/* regra 132 */
	private void constroiCondicaoPara() {

		NodoEstrutura nodoEstrutura;
		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;
		String labelFimLacoPara;

		nodoEstrutura = pilhaEstrutura.pop();
		labelFimLacoPara = nodoEstrutura.getLabel2();

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do para ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelFimLacoPara,
				"Se falso, vai para: " + labelFimLacoPara));

		pilhaEstrutura.push(nodoEstrutura);
	}

	/* regra 133 */
	private void realizaAtribuicaoLacoPara() {

		NodoPilhaSemantica variavelControle, ladoDireito;
		int tipoVariavelControle, tipoLadoDireito;
		String descricaoVariavelControle, descricaoLadoDireito;

		variavelControle = pilhaSemantica.pop();
		tipoVariavelControle = variavelControle.getTipoAssociado();
		descricaoVariavelControle = variavelControle.getCodigo();
		exibeMensagemSemantico("Desempilhei vari�vel de controle ("
				+ traduzAliasTipo(tipoVariavelControle) + "): "
				+ descricaoVariavelControle);

		pilhaSemantica.push(variavelControle); // Empilho variavel de controle
												// para ser usada no incremento
		pilhaSemantica.push("1", Lexico.T_INTEIRO, 133);

		somaTermos();

		ladoDireito = pilhaSemantica.pop();
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);

		if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
			fonte.append(formataMacro(null, "MOV", "R0, "
					+ descricaoVariavelControle, "Efetuo atribui��o"));
		} else {
			fonte.append(formataMacro(null, "MOV", descricaoLadoDireito + ", "
					+ descricaoVariavelControle, "Efetuo atribui��o"));
		}
	}

	/* regra 134 */
	private void constroiFimPara() {

		NodoEstrutura nodoEstrutura;

		nodoEstrutura = pilhaEstrutura.pop();
		fonte.append(formataMacro(null, "JMP", nodoEstrutura.getLabel1(),
				"Volta a testar condi��o do la�o para: "
						+ nodoEstrutura.getLabel1()));
		fonte.append(formataMacro(nodoEstrutura.getLabel2(), "NOP", "",
				"fim do la�o para: " + nodoEstrutura.getLabel2()));
	}

	/* regra 135 */
	private void constroiInicioRepita() {

		NodoEstrutura nodoEstrutura;
		String labelInicioRepita;
		String labelFimRepita;

		labelInicioRepita = proximoLabel();
		labelFimRepita = proximoLabel();
		nodoEstrutura = new NodoEstrutura(labelInicioRepita, labelFimRepita,
				PilhaEstrutura.T_REPITA);
		pilhaEstrutura.push(nodoEstrutura);

		fonte.append(formataMacro(labelInicioRepita, "NOP", "",
				"Inicio do Repita"));
	}

	/* regra 136 */
	private void constroiCondicaoRepitaAte() {

		NodoEstrutura nodoEstrutura;
		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;
		String labelInicioRepita;

		nodoEstrutura = pilhaEstrutura.pop();
		labelInicioRepita = nodoEstrutura.getLabel1();

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do repita ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelInicioRepita,
				"Se falso, vai para: " + labelInicioRepita));
	}

	/* regra 137 */
	private void constroiCondicaoRepitaEnquanto() {

		NodoEstrutura nodoEstrutura;
		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;
		String labelInicioRepita;

		nodoEstrutura = pilhaEstrutura.pop();
		labelInicioRepita = nodoEstrutura.getLabel1();

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do repita ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "1, R0", "Testo se verdadeiro"));
		fonte.append(formataMacro(null, "BEQ", labelInicioRepita,
				"Se verdadeiro, vai para: " + labelInicioRepita));
	}

	/* regra 140 */
	private void constroiPrimeiraClausulaCaso() {

		System.out.println("constroiPrimeiraClausulaCaso");

		NodoEstrutura nodoEstrutura;
		String labelHerdado;
		String labelFimCaso;
		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;

		labelHerdado = proximoLabel();
		labelFimCaso = proximoLabel();
		nodoEstrutura = new NodoEstrutura(labelFimCaso, labelHerdado,
				PilhaEstrutura.T_CASO);
		pilhaEstrutura.push(nodoEstrutura);

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do caso ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelHerdado,
				"Se falso, vai para: " + labelHerdado));

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonteParaDebug.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonteParaDebug.append(formataMacro(null, "CMP", "0, R0",
				"Testo se falso"));
		fonteParaDebug.append(formataMacro(null, "BEQ", labelHerdado,
				"Se falso, vai para: " + labelHerdado));

		System.out.println(fonteParaDebug.toString());
		System.out
				.println("---------------------------------------------------------------------");

	}

	/* regra 141 */
	private void constroiInicioClausulasSeguintesCaso() {

		System.out.println("constroiInicioClausulasSeguintesCaso");

		NodoEstrutura nodoEstrutura;
		String labelHerdado;
		String labelFimCaso;

		nodoEstrutura = pilhaEstrutura.pop();

		labelFimCaso = nodoEstrutura.getLabel1();
		labelHerdado = nodoEstrutura.getLabel2();

		NodoPilhaSemantica nodoOp;
		int tipoOp;
		String descricaoOp;
		String labelSenao;

		labelHerdado = proximoLabel();
		nodoEstrutura = new NodoEstrutura(labelFimCaso, labelHerdado,
				PilhaEstrutura.T_CASO);
		pilhaEstrutura.push(nodoEstrutura);

		nodoOp = pilhaSemantica.pop();
		tipoOp = nodoOp.getTipoAssociado();
		descricaoOp = nodoOp.getCodigo();
		exibeMensagemSemantico("Desempilhei condi��o do caso ("
				+ traduzAliasTipo(tipoOp) + "): " + descricaoOp);

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonte.append(formataMacro(null, "CMP", "0, R0", "Testo se falso"));
		fonte.append(formataMacro(null, "BEQ", labelHerdado,
				"Se falso, vai para: " + labelHerdado));

		if (nodoOp.getCodigo().equalsIgnoreCase("$temp")) {
			fonteParaDebug.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
		}
		fonteParaDebug.append(formataMacro(null, "CMP", "0, R0",
				"Testo se falso"));
		fonteParaDebug.append(formataMacro(null, "BEQ", labelHerdado,
				"Se falso, vai para: " + labelHerdado));

		System.out.println(fonteParaDebug.toString());
		System.out
				.println("---------------------------------------------------------------------");

	}

	/* regra 142 */
	private void constroiFimCaso() {

		System.out.println("constroiFimCaso");

		NodoEstrutura nodoEstrutura;

		nodoEstrutura = pilhaEstrutura.pop();

		fonte.append(formataMacro(nodoEstrutura.getLabel1(), "NOP", "",
				"fim do caso: " + nodoEstrutura.getLabel1()));
		fonteParaDebug.append(formataMacro(nodoEstrutura.getLabel1(), "NOP",
				"", "fim do caso: " + nodoEstrutura.getLabel1()));

		System.out.println(fonteParaDebug.toString());
		System.out
				.println("---------------------------------------------------------------------");
	}

	/* regra 143 */
	private void constroiSaltoParaFimDoCaso() {

		System.out.println("constroiSaltoParaFimDoCaso");

		NodoEstrutura nodoEstrutura;
		String labelHerdado;
		String labelFimCaso;

		nodoEstrutura = pilhaEstrutura.pop();

		labelFimCaso = nodoEstrutura.getLabel1();
		labelHerdado = nodoEstrutura.getLabel2();

		fonte.append(formataMacro(null, "JMP", labelFimCaso,
				"Vai para o fim do verdadeiro: " + labelFimCaso));
		fonteParaDebug.append(formataMacro(null, "JMP", labelFimCaso,
				"Vai para o fim do verdadeiro: " + labelFimCaso));
		fonte.append(formataMacro(labelHerdado, "NOP", "",
				"Inicio de Clausula Caso: " + labelHerdado));
		fonteParaDebug.append(formataMacro(labelHerdado, "NOP", "",
				"Inicio de Clausula Caso: " + labelHerdado));

		pilhaEstrutura.push(nodoEstrutura);

		System.out.println(fonteParaDebug.toString());
		System.out
				.println("---------------------------------------------------------------------");

	}

	/* regra 144 */
	private void constroiClausulasSenaoCaso() {

		System.out.println("constroiClausulasSenaoCaso");

		fonte.append(formataMacro(null, "NOP", "", "Caso contr�rio..."));
		fonteParaDebug
				.append(formataMacro(null, "NOP", "", "Caso contr�rio..."));

		System.out.println(fonteParaDebug.toString());
		System.out
				.println("---------------------------------------------------------------------");

	}

	/* regra 155 */
	private void estabeleceRotulo() {

		String rotulo = lexico.getUltimoLexema().toUpperCase();
		String label = null;
		
		if( listaRotulos.get(rotulo) == null ){
			label = proximoLabel();
			listaRotulos.put(rotulo, new NodoRotulo( label, funcaoDeclarandoAtualmente ));
			fonte.append(formataMacro(label, "NOP", "", "R�tulo: " + rotulo));
		}
	}

	/* regra 160 */
	private void implementaVaPara() {

		String rotulo = lexico.getUltimoLexema().toUpperCase();
		String label = null;
		String funcaoOndeRotuloFoiDeclarado = null;
		NodoRotulo nodo = listaRotulos.get(rotulo);
		
		if( nodo == null ){
			label = proximoLabel();
			listaRotulos.put(rotulo, new NodoRotulo( label, funcaoDeclarandoAtualmente ));
		} else {
			funcaoOndeRotuloFoiDeclarado = nodo.getFuncao();
			if ( !funcaoDeclarandoAtualmente.equalsIgnoreCase( funcaoOndeRotuloFoiDeclarado ) ) {
				throw new ErroSemanticoException("Refer�ncia de R�tulo inv�lida: " + rotulo + " ! " );
			} 
			label = nodo.getLabel();
		}
		fonte.append(formataMacro(null, "JMP", label, "Vai incondicionalmente para: " + label + "( " + rotulo + " )"));	
	}
	
	/* regra 180 */
	private void invocaApagaTela() {

		fonte.append(formataMacro(null, "JSR", "#CLRSCR",
				"Apaga a tela (visor) do Cesar"));
	}

	/* regra 190 */
	private void realizaRetornoDeFuncao() {

		NodoPilhaSemantica ladoDireito;
		int tipoLadoDireito;
		String descricaoLadoDireito;
		SimboloTabela st;
		String enderecoRetorno;

		ladoDireito = pilhaSemantica.pop();
		tipoLadoDireito = ladoDireito.getTipoAssociado();
		descricaoLadoDireito = ladoDireito.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoLadoDireito) + "): "
				+ descricaoLadoDireito);

		st = buscaTabelaSimbolos(funcaoDeclarandoAtualmente,
				SimboloTabela.T_FUNCAO);

		enderecoRetorno = "[R5+" + st.getEndereco() + "]";

		if (ladoDireito.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho resultado da express�o"));
			fonte.append(formataMacro(null, "MOV", "R0, " + enderecoRetorno,
					"Transfiro valor de retorno"));
		} else {
			fonte.append(formataMacro(null, "MOV", descricaoLadoDireito + ", "
					+ enderecoRetorno, "Transfiro valor de retorno"));
		}
	}

	/* regra 205 */
	private void expressao() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei fator_logico ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei fator_logico ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho tempor�ria l�gica"));
		}

		if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho tempor�ria l�gica"));
		}

		caso = T_OP_OP;

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			caso = T_PILHA_OP;
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_PILHA;
			}
		} else {
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_OP_PILHA;
			}
		}

		if (tipoOp1 == Lexico.T_LOGICO && tipoOp2 == Lexico.T_LOGICO) {

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro fator l�gico para R0"));
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "OR", descricaoOp2 + ", R0",
						"Aplico conectivo l�gico 'OU'"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "OR", descricaoOp2 + ", R0",
						"Aplico conectivo l�gico 'OU'"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro fator l�gico para R0"));
				fonte.append(formataMacro(null, "OR", "R1, R0",
						"Aplico conectivo l�gico 'OU' em R1"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "OR", "R1, R0",
						"Aplico conectivo l�gico 'OU' em R1"));
				break;
			}

			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria l�gica"));
			pilhaSemantica.push("$temp", Lexico.T_LOGICO, 205);
		} else {
			throw new ErroSemanticoException(
					"Opera��o l�gica inv�lida para tipos: "
							+ Lexico.getDsTipoDeclarado(tipoOp1) + " e "
							+ Lexico.getDsTipoDeclarado(tipoOp2));
		}
	}

	/* regra 210 */
	private void termoLogico() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei fator_logico ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei fator_logico ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho tempor�ria l�gica"));
		}

		if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho tempor�ria l�gica"));
		}

		caso = T_OP_OP;

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			caso = T_PILHA_OP;
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_PILHA;
			}
		} else {
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_OP_PILHA;
			}
		}

		if (tipoOp1 == Lexico.T_LOGICO && tipoOp2 == Lexico.T_LOGICO) {

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro fator l�gico para R0"));
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "AND", descricaoOp2 + ", R0",
						"Aplico conectivo l�gico 'E'"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "AND", descricaoOp2 + ", R0",
						"Aplico conectivo l�gico 'E'"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro fator l�gico para R0"));
				fonte.append(formataMacro(null, "AND", "R1, R0",
						"Aplico conectivo l�gico 'E' em R1"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "AND", "R1, R0",
						"Aplico conectivo l�gico 'E' em R1"));
				break;
			}

			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria l�gica"));
			pilhaSemantica.push("$temp", Lexico.T_LOGICO, 210);
		} else {
			throw new ErroSemanticoException(
					"Opera��o l�gica inv�lida para tipos: "
							+ Lexico.getDsTipoDeclarado(tipoOp1) + " e "
							+ Lexico.getDsTipoDeclarado(tipoOp2));
		}
	}

	/* regras 212 e 213 */
	private void comparaIgualdades(String funcaoChamada, int numeroRegra) {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;
		String label1, label2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei relacao_igualdade ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei relacao_igualdade ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho tempor�ria"));
		}

		if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho tempor�ria"));
		}

		caso = T_OP_OP;

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			caso = T_PILHA_OP;
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_PILHA;
			}
		} else {
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_OP_PILHA;
			}
		}

		if ((tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO)
				|| (tipoOp1 == Lexico.T_LOGICO && tipoOp2 == Lexico.T_LOGICO)) {

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeira relacao para R0"));
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "CMP", descricaoOp2 + ", R0",
						"Efetuo compara��o entre as rela��es"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "CMP", descricaoOp2 + ", R0",
						"Efetuo compara��o entre as rela��es"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeira relacao para R0"));
				fonte.append(formataMacro(null, "CMP", "R1, R0",
						"Movimento segunda relacao para R1"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "CMP", "R1, R0",
						"Movimento segunda relacao para R1"));
				break;
			}

			label1 = proximoLabel();
			label2 = proximoLabel();
			if (funcaoChamada.equalsIgnoreCase("BEQ")) {
				fonte.append(formataMacro(null, "BEQ", label1,
						"Compara igualdade"));
			} else {
				fonte.append(formataMacro(null, "BNE", label1,
						"Compara desigualdade"));
			}

			fonte.append(formataMacro(null, "PUSH", "0", "Falso"));
			fonte.append(formataMacro(null, "JMP", label2, " "));
			fonte.append(formataMacro(label1, "PUSH", "1", "Verdadeiro"));
			fonte.append(formataMacro(label2, "NOP", " ", " "));
			pilhaSemantica.push("$temp", Lexico.T_LOGICO, numeroRegra);
		} else {
			if (tipoOp1 == Lexico.T_CARACTER && tipoOp2 == Lexico.T_CARACTER) {

				switch (caso) {
				case T_OP_OP:
					popDeVetor( nodoOp1 );
					fonte.append(formataMacro(null, "MOV", descricaoOp1
							+ ", R0", "Movimento primeira string para R0"));
					popDeVetor( nodoOp2 );
					fonte.append(formataMacro(null, "MOV", descricaoOp2
							+ ", R1", "Movimento segunda string para R1"));
					break;
				case T_PILHA_OP:
					popDeVetor( nodoOp2 );
					fonte.append(formataMacro(null, "MOV", descricaoOp2
							+ ", R1", "Movimento segunda string para R1"));
					break;
				case T_OP_PILHA:
					popDeVetor( nodoOp1 );
					fonte.append(formataMacro(null, "MOV", descricaoOp1
							+ ", R0", "Movimento primeira relacao para R0"));
					break;
				case T_PILHA_PILHA:
					break;
				}
				if (funcaoChamada.equalsIgnoreCase("BEQ")) {
					fonte.append(formataMacro(null, "JSR", "#STREQ",
							"Compara igualdade de strings"));
				} else {
					fonte.append(formataMacro(null, "JSR", "#STRNE",
							"Compara desigualdade de strings"));
				}
				fonte.append(formataMacro(null, "PUSH", "R0",
						"Empilho resultado da compara��o de strings"));
				pilhaSemantica.push("$temp", Lexico.T_LOGICO, numeroRegra);
			} else {
				throw new ErroSemanticoException(
						"Opera��o l�gica inv�lida para tipos: "
								+ Lexico.getDsTipoDeclarado(tipoOp1) + " e "
								+ Lexico.getDsTipoDeclarado(tipoOp2));
			}
		}
	}

	/* regra 220 */
	private void comparaExpressoes(String funcaoChamada, int numeroRegra) {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;
		String label1, label2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei express�o_simples ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei express�o_simples ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho tempor�ria"));
		}

		if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R1",
					"Desempilho tempor�ria"));
		}

		caso = T_OP_OP;

		if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
			caso = T_PILHA_OP;
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_PILHA;
			}
		} else {
			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_OP_PILHA;
			}
		}

		if (tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO) {

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "MOV", descricaoOp2 + ", R0",
						"Movimento primeira express�o simples para R0"));
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "CMP", descricaoOp1 + ", R0",
						"Efetuo compara��o de Inteiros"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "CMP", descricaoOp1 + ", R0",
						"Efetuo compara��o de Inteiros"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "MOV", descricaoOp2 + ", R0",
						"Movimento primeira express�o simples para R0"));
				fonte.append(formataMacro(null, "CMP", "R1, R0",
						"Movimento segunda express�o simples para R1"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "CMP", "R1, R0",
						"Movimento segunda express�o simples para R1"));
				break;
			}

			label1 = proximoLabel();
			label2 = proximoLabel();
			if (funcaoChamada.equalsIgnoreCase("BGT")) {
				fonte.append(formataMacro(null, "BGT", label1,
						"Compara se maior"));
			} else if (funcaoChamada.equalsIgnoreCase("BLT")) {
				fonte.append(formataMacro(null, "BLT", label1,
						"Compara se menor"));
			} else if (funcaoChamada.equalsIgnoreCase("BGE")) {
				fonte.append(formataMacro(null, "BGE", label1,
						"Compara se maior ou igual"));
			} else {
				fonte.append(formataMacro(null, "BLE", label1,
						"Compara se menor ou igual"));
			}

			fonte.append(formataMacro(null, "PUSH", "0", "Falso"));
			fonte.append(formataMacro(null, "JMP", label2, " "));
			fonte.append(formataMacro(label1, "PUSH", "1", "Verdadeiro"));
			fonte.append(formataMacro(label2, "NOP", " ", " "));
			pilhaSemantica.push("$temp", Lexico.T_LOGICO, numeroRegra);
		} else {
			if (tipoOp1 == Lexico.T_CARACTER && tipoOp2 == Lexico.T_CARACTER) {

				switch (caso) {
				case T_OP_OP:
					fonte.append(formataMacro(null, "MOV", descricaoOp1
							+ ", R0", "Movimento primeira string para R0"));
					fonte.append(formataMacro(null, "MOV", descricaoOp2
							+ ", R1", "Movimento segunda string para R1"));
					break;
				case T_PILHA_OP:
					fonte.append(formataMacro(null, "MOV", descricaoOp2
							+ ", R1", "Movimento segunda string para R1"));
					break;
				case T_OP_PILHA:
					fonte.append(formataMacro(null, "MOV", descricaoOp1
							+ ", R0", "Movimento primeira relacao para R0"));
					break;
				case T_PILHA_PILHA:
					break;
				}
				if (funcaoChamada.equalsIgnoreCase("BGT")) {
					fonte.append(formataMacro(null, "JSR", "#STRGT",
							"Compara se string a > b"));
				} else if (funcaoChamada.equalsIgnoreCase("BLT")) {
					fonte.append(formataMacro(null, "JSR", "#STRLT",
							"Compara se string a < b"));
				} else if (funcaoChamada.equalsIgnoreCase("BGE")) {
					fonte.append(formataMacro(null, "JSR", "#STRGE",
							"Compara se string a >= b"));
				} else {
					fonte.append(formataMacro(null, "JSR", "#STRLE",
							"Compara se string a <= b"));
				}
				fonte.append(formataMacro(null, "PUSH", "R0",
						"Empilho resultado da compara��o de strings"));
				pilhaSemantica.push("$temp", Lexico.T_LOGICO, numeroRegra);
			} else {
				throw new ErroSemanticoException(
						"Opera��o l�gica inv�lida para tipos: "
								+ Lexico.getDsTipoDeclarado(tipoOp1) + " e "
								+ Lexico.getDsTipoDeclarado(tipoOp2));
			}
		}
	}

	/* regra 227 - Incompleta falta concatena��o */
	private void somaTermos() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei termo (" + traduzAliasTipo(tipoOp2)
				+ "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei termo (" + traduzAliasTipo(tipoOp1)
				+ "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO) {

			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria inteira"));
			}

			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R1",
						"Desempilho tempor�ria inteira"));
			}

			caso = T_OP_OP;

			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_OP;
				if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
					caso = T_PILHA_PILHA;
				}
			} else {
				if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
					caso = T_OP_PILHA;
				}
			}

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro operador da adi��o para R0"));
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "ADD", descricaoOp2 + ", R0",
						"Efetuo adi��o de Inteiros"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "ADD", descricaoOp2 + ", R0",
						"Efetuo adi��o de Inteiros"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro operador da adi��o para R0"));
				fonte.append(formataMacro(null, "ADD", "R1, R0",
						"Efetuo adi��o de Inteiros"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "ADD", "R1, R0",
						"Efetuo adi��o de Inteiros"));
				break;
			}
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria inteira"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 227);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de Adi��o ou Concatena��o inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 229 */
	private void subtraiTermos() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2, caso;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei termo (" + traduzAliasTipo(tipoOp2)
				+ "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei termo (" + traduzAliasTipo(tipoOp1)
				+ "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO) {

			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria inteira"));
			}

			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R1",
						"Desempilho tempor�ria inteira"));
			}

			caso = T_OP_OP;

			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				caso = T_PILHA_OP;
				if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
					caso = T_PILHA_PILHA;
				}
			} else {
				if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
					caso = T_OP_PILHA;
				}
			}

			switch (caso) {
			case T_OP_OP:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro operador da adi��o para R0"));
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "SUB", descricaoOp2 + ", R0",
						"Efetuo subtra��o de Inteiros"));
				break;
			case T_PILHA_OP:
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "SUB", descricaoOp2 + ", R0",
						"Efetuo subtra��o de Inteiros"));
				break;
			case T_OP_PILHA:
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro operador da adi��o para R0"));
				fonte.append(formataMacro(null, "SUB", "R1, R0",
						"Efetuo subtra��o de Inteiros"));
				break;
			case T_PILHA_PILHA:
				fonte.append(formataMacro(null, "SUB", "R1, R0",
						"Efetuo subtra��o de Inteiros"));
				break;
			}
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria inteira"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 227);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de Subtra��o inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 232 */
	private void multiplicaUnarios() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei unario ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei unario ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO) {
			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria inteira"));
			}

			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R1",
						"Desempilho tempor�ria inteira"));
			}

			if (!nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV",
								descricaoOp1 + ", R0",
								"Movimento primeiro operador da multiplica��o para R0"));
			}
			if (!nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "MOV", descricaoOp2 + ", R1",
						"Movimento segundo operador da multiplica��o para R1"));
			}
			fonte.append(formataMacro(null, "JSR", "#IMUL",
					"Chamo rotina de multiplica��o de Inteiros"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria inteira"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 232);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de Multiplica��o inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 234 */
	private void divideUnarios() {

		NodoPilhaSemantica nodoOp1, nodoOp2;
		int tipoOp1, tipoOp2;
		String descricaoOp1, descricaoOp2;

		nodoOp2 = pilhaSemantica.pop();
		tipoOp2 = nodoOp2.getTipoAssociado();
		descricaoOp2 = nodoOp2.getCodigo();
		exibeMensagemSemantico("Desempilhei unario ("
				+ traduzAliasTipo(tipoOp2) + "): " + descricaoOp2);
		nodoOp1 = pilhaSemantica.pop();
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei unario ("
				+ traduzAliasTipo(tipoOp1) + "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_INTEIRO && tipoOp2 == Lexico.T_INTEIRO) {
			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria inteira"));
			}

			if (nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R1",
						"Desempilho tempor�ria inteira"));
			}

			if (!nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				popDeVetor( nodoOp1 );
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento primeiro operador da divis�o para R0"));
			}

			if (!nodoOp2.getCodigo().equalsIgnoreCase("$temp")) {
				popDeVetor( nodoOp2 );
				fonte.append(formataMacro(null, "MOV", descricaoOp2 + ", R1",
						"Movimento segundo operador da divis�o para R1"));
			}
			fonte.append(formataMacro(null, "JSR", "#IDIV",
					"Chamo rotina de divis�o de Inteiros"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria inteira"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 232);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de divis�o inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 240 */
	private void negativaFator() {

		NodoPilhaSemantica nodoOp1;
		int tipoOp1;
		String descricaoOp1;

		nodoOp1 = pilhaSemantica.pop();
		popDeVetor( nodoOp1 );
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei fator (" + traduzAliasTipo(tipoOp1)
				+ "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_INTEIRO) {
			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria inteira"));
			}

			if (!nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento fator inteiro para R0"));
			}

			fonte.append(formataMacro(null, "MOV", "-1, R1",
					"armazeno -1 em R1"));
			fonte.append(formataMacro(null, "JSR", "#IMUL",
					"multiplico R0 por -1"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria inteira"));
			pilhaSemantica.push("$temp", Lexico.T_INTEIRO, 245);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de 'menos un�rio' inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 245 */
	private void negaFator() {

		NodoPilhaSemantica nodoOp1;
		int tipoOp1;
		String descricaoOp1;

		nodoOp1 = pilhaSemantica.pop();
		popDeVetor( nodoOp1 );
		tipoOp1 = nodoOp1.getTipoAssociado();
		descricaoOp1 = nodoOp1.getCodigo();
		exibeMensagemSemantico("Desempilhei fator (" + traduzAliasTipo(tipoOp1)
				+ "): " + descricaoOp1);

		if (tipoOp1 == Lexico.T_LOGICO) {
			if (nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "POP", "R0",
						"Desempilho tempor�ria l�gica"));
			}

			if (!nodoOp1.getCodigo().equalsIgnoreCase("$temp")) {
				fonte.append(formataMacro(null, "MOV", descricaoOp1 + ", R0",
						"Movimento fator l�gico para R0"));
			}

			fonte.append(formataMacro(null, "SUB", "1, R0", "preparo 'NOT'"));
			fonte.append(formataMacro(null, "NOT", "R0", "Efetuo nega��o"));
			fonte
					.append(formataMacro(null, "ADD", "1, R0",
							"restauro conte�do"));
			fonte.append(formataMacro(null, "PUSH", "R0",
					"Empilho tempor�ria l�gica"));
			pilhaSemantica.push("$temp", Lexico.T_LOGICO, 245);
		} else {
			throw new ErroSemanticoException(
					"Opera��o de nega��o inv�lida para tipo: "
							+ Lexico.getDsTipoDeclarado(tipoOp1));
		}
	}

	/* regra 255 */
	private void empilhaFatorInteiro() {

		pilhaSemantica.push(lexico.getUltimoLexema(), Lexico.T_INTEIRO, 255);
		exibeMensagemSemantico("Empilhei fator inteiro: "
				+ lexico.getUltimoLexema());
	}

	/* regra 265 */
	private void empilhaFatorCaracter() {

		String codigo;

		codigo = proximaCadeia();

		fonteRodape.append("\n" + codigo + ":\n\t" + "\""
				+ lexico.getUltimoLexema() + "\"");

		pilhaSemantica.push(codigo, Lexico.T_CARACTER, 255);
		exibeMensagemSemantico("Empilhei fator texto: "
				+ lexico.getUltimoLexema());
	}

	/* regra 270 */
	private void empilhaFatorLogico() {

		if (lexico.getUltimoToken() == Lexico.T_VERDADEIRO) {
			pilhaSemantica.push("1", Lexico.T_LOGICO, 270);
		} else {
			pilhaSemantica.push("0", Lexico.T_LOGICO, 270);
		}
		exibeMensagemSemantico("Empilhei fator logico: "
				+ lexico.getUltimoLexema());
	}

	/* regra 300 */
	private void marcaInicioArgumentos() {

		fonte.append(formataMacro(null, "SUB", "2, R6",
				"Abro espa�o para o valor do retorno"));

		// empilho inicio dos argumentos
		pilhaSemantica.push("#argumentos#", Lexico.T_DESCONHECIDO, 47);
	}

	/* regra 301 */
	private void realizaChamadaFuncao() {

		/**
		 * TODO falta conferir os argumentos. Para tal, uma solu��o poss�vel �
		 * implementar cabe�alhos de fun��o tal como no C.
		 */

		// desempilho nome da fun��o
		NodoPilhaSemantica nomeFuncaoEmpilhado;
		NodoPilhaSemantica argumento;
		String nomeFuncao;
		String descricaoArgumento;
		int espacoParametros;

		boolean continua = true;
		espacoParametros = 0;

		do {
			argumento = pilhaSemantica.pop();
			descricaoArgumento = argumento.getCodigo();

			if (argumento.getCodigo().equals("#argumentos#")) {
				exibeMensagemSemantico("Desempilhei marcador: "
						+ argumento.getCodigo());
				continua = false;
			} else {
				espacoParametros += tamanhoTipo(argumento.getTipoAssociado());

				if (argumento.getCodigo().equalsIgnoreCase("$temp")) {
					if (argumento.getTipoAssociado() == Lexico.T_INTEIRO) {
						// n�o faz nada pop + push
					} else {
						fonte.append(formataMacro(null, "FALTA TRATAR STRINGS",
								"FALTA", "Falta Tratar Strings"));
						fonte.append(formataMacro(null, "PUSH",
								descricaoArgumento, "Empilho argumento"));
					}
				} else {
					fonte.append(formataMacro(null, "PUSH", descricaoArgumento,
							"Empilho argumento"));
				}
				exibeMensagemSemantico("Desempilhei inicio dos argumentos: "
						+ argumento.getCodigo());
			}
		} while (continua);

		nomeFuncaoEmpilhado = pilhaSemantica.pop();
		nomeFuncao = nomeFuncaoEmpilhado.getCodigo();

		fonte.append(formataMacro(null, "JSR", nomeFuncao,
				"Realizo a chamada da fun��o"));

		if (espacoParametros > 0) {
			fonte.append(formataMacro(null, "ADD", espacoParametros + ", R6",
					"Desempilho espa�o usado pelos argumentos"));
		}

		pilhaSemantica.push("$temp", nomeFuncaoEmpilhado.getTipoAssociado(),
				301);
		System.out.println("Empilhei "
				+ nomeFuncaoEmpilhado.getDsTipoAssociado());

		exibeMensagemSemantico("Desempilhei nome da fun��o: " + nomeFuncao);
	}

	/* regra 380 */
	private void resolveReferenciaIdAtribuicao() {

		NodoPilhaSemantica nodoPilha;
		SimboloTabela st;
		String referencia;

		nodoPilha = pilhaSemantica.pop();

		st = buscaTabelaSimbolos(nodoPilha.getCodigo());

		if (st == null) {
			throw new ErroSemanticoException("Vari�vel n�o declarada: "
					+ nodoPilha.getCodigo());
		} else if ( st.isConstante() ) {	
			throw new ErroSemanticoException("N�o posso realizar atribui��o para constante: "
					+ nodoPilha.getCodigo());
		} else if ( st.isVetor() ) {	
			throw new ErroSemanticoException("N�o posso realizar atribui��o sem a respectiva indexa��o: " + nodoPilha.getCodigo() );
		} else {
			if (st.getClasse() == SimboloTabela.T_FUNCAO) {
				pilhaSemantica.push(nodoPilha);
			} else {
				if (st.getClasse() == SimboloTabela.T_GLOBAL) {
					if (st.getTipo() == Lexico.T_CARACTER) {
						referencia = Integer.toString(st.getEndereco());
					} else {
						referencia = "[" + Integer.toString(st.getEndereco())
								+ "]";
					}
				} else {
					if (st.getEndereco() < 0) {
						referencia = "[R5" + Integer.toString(st.getEndereco())
								+ "]";
					} else {
						referencia = "[R5+"
								+ Integer.toString(st.getEndereco()) + "]";
					}
				}
				pilhaSemantica.push(referencia, st.getTipo(), 400);
			}
		}
	}

	/* regra 382 */
	private void resolveReferenciaIdAtribuicaoVetor() {

		NodoPilhaSemantica nodoPilha;
		NodoPilhaSemantica nodoPilhaContendoPosicao;
		SimboloTabela st;
		String referencia;

		int tipoPosicao;
		String descricaoPosicao;

		//Eskeff
		nodoPilhaContendoPosicao = pilhaSemantica.pop();
		tipoPosicao = nodoPilhaContendoPosicao.getTipoAssociado();
		descricaoPosicao = nodoPilhaContendoPosicao.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoPosicao) + "): "
				+ descricaoPosicao);
		
		if (nodoPilhaContendoPosicao.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho posi��o do vetor em R0 "));
		} else {
			fonte.append(formataMacro(null, "MOV",
					descricaoPosicao + ", "
									+ "R0",
							"Movimento posi��o do vetor para R0"));
		}
		//Eskeff
		
		nodoPilha = pilhaSemantica.pop();

		st = buscaTabelaSimbolos(nodoPilha.getCodigo());

		if (st == null) {
			throw new ErroSemanticoException("Vari�vel n�o declarada: "
					+ nodoPilha.getCodigo());
		} else if ( st.isConstante() ) {	
			throw new ErroSemanticoException("N�o posso realizar atribui��o para constante: "
					+ nodoPilha.getCodigo());
		} else if ( !st.isVetor() ) {	
			throw new ErroSemanticoException("Indexa��o inv�lida: Vari�vel " + nodoPilha.getCodigo() + " n�o foi criada como um vetor" );
		} else {
			if (st.getClasse() == SimboloTabela.T_GLOBAL) {
				if (st.getTipo() == Lexico.T_CARACTER) {
					// Eskeff
					referencia = Integer.toString(st.getEndereco());
				} else {
					referencia = Integer.toString(st.getEndereco());
				}
				fonte.append(formataMacro(null, "MOV", referencia + ", R1", "Desempilho a base do vetor em R1 "));
			} else {
				fonte.append(formataMacro(null, "MOV", "[R5], R1", "Desempilho a base do vetor em R1 "));
				if (st.getEndereco() < 0) {
					referencia = "[R5" + Integer.toString(st.getEndereco())
							+ "]";
					fonte.append(formataMacro(null, "SUB", Integer.toString( Math.abs( st.getEndereco() ) )+", R1", "Subtraio offset de R1 "));
				} else {
					referencia = "[R5+"
							+ Integer.toString(st.getEndereco()) + "]";
					fonte.append(formataMacro(null, "ADD", Integer.toString(st.getEndereco())+", R1", "Somo offset em R1 "));
				}
			}
			pilhaSemantica.push(referencia, st.getTipo(), 400); // Acho que � inutil
		}
		if ( st.getTipo() == Lexico.T_CARACTER ) {
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 "));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 4)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 8)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 16)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 32)"));
		} else {
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 "));
		}
		fonte.append(formataMacro(null, "SUB", "R0, R1", "Subtraio o offset da base do vetor"));
		fonte.append(formataMacro(null, "PUSH", "R1", "Empilho endere�o calculado do vetor"));
		
	}

	/* regra 400 */
	private void resolveReferenciaId() {

		NodoPilhaSemantica nodoPilha;
		SimboloTabela st;
		String referencia;

		nodoPilha = pilhaSemantica.pop();

		st = buscaTabelaSimbolos(nodoPilha.getCodigo());
		
		if (st == null) {
			throw new ErroSemanticoException("Vari�vel n�o declarada: "
					+ nodoPilha.getCodigo());
		} else {
			if (st.getClasse() == SimboloTabela.T_FUNCAO) {
				pilhaSemantica.push(nodoPilha);
			} else {
				if (st.getClasse() == SimboloTabela.T_GLOBAL) {
					if (st.getTipo() == Lexico.T_CARACTER) {
						referencia = Integer.toString(st.getEndereco());
					} else {
						referencia = "[" + Integer.toString(st.getEndereco())
								+ "]";
					}
				} else {
					if (st.getEndereco() < 0) {
						referencia = "[R5" + Integer.toString(st.getEndereco())
								+ "]";
					} else {
						referencia = "[R5+"
								+ Integer.toString(st.getEndereco()) + "]";
					}
				}
				pilhaSemantica.push(referencia, st.getTipo(), 400);
			}
		}
	}

	/* regra 404 */
	private void resolveReferenciaIdVetor() {

		NodoPilhaSemantica nodoPilha;
		NodoPilhaSemantica nodoPilhaContendoPosicao;
		SimboloTabela st;
		String referencia;

		int tipoPosicao;
		String descricaoPosicao;

		//Eskeff
		nodoPilhaContendoPosicao = pilhaSemantica.pop();
		tipoPosicao = nodoPilhaContendoPosicao.getTipoAssociado();
		descricaoPosicao = nodoPilhaContendoPosicao.getCodigo();
		exibeMensagemSemantico("Desempilhei expressao ("
				+ traduzAliasTipo(tipoPosicao) + "): "
				+ descricaoPosicao);
		
		if (nodoPilhaContendoPosicao.getCodigo().equalsIgnoreCase("$temp")) {
			fonte.append(formataMacro(null, "POP", "R0",
					"Desempilho posi��o do vetor em R0 "));
		} else {
			fonte.append(formataMacro(null, "MOV",
					descricaoPosicao + ", "
									+ "R0",
							"Movimento posi��o do vetor para R0"));
		}
		//Eskeff
		
		nodoPilha = pilhaSemantica.pop();

		st = buscaTabelaSimbolos(nodoPilha.getCodigo());

		if (st == null) {
			throw new ErroSemanticoException("Vari�vel n�o declarada: "
					+ nodoPilha.getCodigo());
		} else if ( st.isConstante() ) {	
			throw new ErroSemanticoException("N�o posso realizar atribui��o para constante: "
					+ nodoPilha.getCodigo());
		} else if ( !st.isVetor() ) {	
			throw new ErroSemanticoException("Indexa��o inv�lida: Vari�vel " + nodoPilha.getCodigo() + " n�o foi criada como um vetor" );
		} else {
			if (st.getClasse() == SimboloTabela.T_GLOBAL) {
				if (st.getTipo() == Lexico.T_CARACTER) {
					// Eskeff
					referencia = Integer.toString(st.getEndereco());
				} else {
					referencia = Integer.toString(st.getEndereco());
				}
				fonte.append(formataMacro(null, "MOV", referencia + ", R1", "Desempilho a base do vetor em R1 "));
			} else {
				fonte.append(formataMacro(null, "MOV", "[R5], R1", "Desempilho a base do vetor em R1 "));
				if (st.getEndereco() < 0) {
					referencia = "[R5" + Integer.toString(st.getEndereco())
							+ "]";
					fonte.append(formataMacro(null, "SUB", Integer.toString( Math.abs( st.getEndereco() ) )+", R1", "Subtraio offset de R1 "));
				} else {
					referencia = "[R5+"
							+ Integer.toString(st.getEndereco()) + "]";
					fonte.append(formataMacro(null, "ADD", Integer.toString(st.getEndereco())+", R1", "Somo offset em R1 "));
				}
			}
//			pilhaSemantica.push(referencia, st.getTipo(), 404); // Acho que � inutil
			pilhaSemantica.push("[R4]", st.getTipo(), 404); // Acho que � inutil
		}
		if ( st.getTipo() == Lexico.T_CARACTER ) {
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 "));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 4)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 8)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 16)"));
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 (x 32)"));
		} else {
			fonte.append(formataMacro(null, "ASL", "R0", "Multiplico por 2 "));
		}
		fonte.append(formataMacro(null, "SUB", "R0, R1", "Subtraio o offset da base do vetor"));
		fonte.append(formataMacro(null, "PUSH", "R1", "Empilho endere�o calculado do vetor"));
		
	}
	
	/* regra 406 */
	private void resolveReferenciaChamadaFuncao() {

		NodoPilhaSemantica nodoPilha;
		SimboloTabela st;

		nodoPilha = pilhaSemantica.pop();

		st = buscaTabelaSimbolos(nodoPilha.getCodigo(), SimboloTabela.T_FUNCAO);

		if (st == null) {
			st = buscaTabelaSimbolos(nodoPilha.getCodigo(),
					SimboloTabela.T_PROTOTIPO);
			if (st == null) {
				throw new ErroSemanticoException("Fun��o nao declarada: "
						+ nodoPilha.getCodigo());
			} else {
				nodoPilha.setTipoAssociado(st.getTipo());
				pilhaSemantica.push(nodoPilha);
			}
		} else {
			nodoPilha.setTipoAssociado(st.getTipo());
			pilhaSemantica.push(nodoPilha);
		}
	}

	/* regras 410 a 414 - serve tamb�m no caso de declara��o de fun��es */
	private void defineTipoSendoDeclarado(int nRegra) {

		tipoSendoDeclarado = lexico.getUltimoToken();
		exibeMensagemSemantico("Tipo sendo declarado setado para: "
				+ Lexico.getDsTipoDeclarado(lexico.getUltimoToken()));
	}

	/* regra 465 */
	private void identificador() {

		String ident;

		ident = lexico.getUltimoLexema().toUpperCase();
		pilhaSemantica.push(ident, Lexico.T_DESCONHECIDO, 465);
	}

	// tratar busca do nome da fun��o mesmo antes de declarado
	public boolean isIdNomeFuncao(String identificador) {
		if (lexico.getToken() == Lexico.T_ABRE_PAR) {
			return true;
		} else {
			return false;
		}
	}

	private void alimentaGlobalTabelaSimbolos(String nome) {

		if (buscaTabelaSimbolos(nome, SimboloTabela.T_GLOBAL) == null) {

			SimboloTabela st = new SimboloTabela(nome, tipoSendoDeclarado,
					SimboloTabela.T_GLOBAL);
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException(
					"A Vari�vel global j� est� declarada:  " + nome);
		}
	}

	private void alimentaGlobalTabelaSimbolos(String nome,
			int enderecoRelativo, boolean constante, boolean vetor) {

		if (buscaTabelaSimbolos(nome, SimboloTabela.T_GLOBAL) == null) {

			SimboloTabela st = new SimboloTabela(nome, tipoSendoDeclarado,
					SimboloTabela.T_GLOBAL, constante, vetor);
			st.setEndereco(enderecoRelativo);
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException(
					"A Vari�vel global j� est� declarada:  " + nome);
		}
	}

	private void alimentaLocalTabelaSimbolos(String nome) {

		if (buscaTabelaSimbolos(nome, SimboloTabela.T_LOCAL) == null) {

			SimboloTabela st = new SimboloTabela(nome, tipoSendoDeclarado,
					SimboloTabela.T_LOCAL, contextoAtual);
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException(
					"A Vari�vel local j� est� declarada:  " + nome);
		}
	}

	private void alimentaLocalTabelaSimbolos(String nome, int enderecoRelativo,
			boolean constante, boolean vetor) {

		if (buscaTabelaSimbolos(nome, SimboloTabela.T_LOCAL) == null) {

			SimboloTabela st = new SimboloTabela(nome, tipoSendoDeclarado,
					SimboloTabela.T_LOCAL, contextoAtual, constante, vetor );
			st.setEndereco(enderecoRelativo);
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException(
					"A Vari�vel local j� est� declarada:  " + nome);
		}
	}

	private void alimentaParametroTabelaSimbolos(String nome,
			int tipoParametro, int enderecoRelativo) {

		if (buscaTabelaSimbolos(nome, SimboloTabela.T_LOCAL) == null) {

			SimboloTabela st = new SimboloTabela(nome, tipoParametro,
					SimboloTabela.T_LOCAL, contextoAtual);
			st.setParametro(true);
			st.setEndereco(enderecoRelativo);
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException("O Par�metro j� est� declarado:  "
					+ nome);
		}
	}

	private void alimentaFuncaoTabelaSimbolos(String nome, boolean declarando,
			int tiposParametros[]) {

		SimboloTabela st = buscaTabelaSimbolos(nome, SimboloTabela.T_FUNCAO);

		if (st == null) {
			st = new SimboloTabela(nome, tipoFuncaoSendoDeclarada,
					SimboloTabela.T_FUNCAO, declarando, tiposParametros);
			st.setContexto(st.getNome());

			// Setando endere�o onde se encontra o valor de retorno
			st.setEndereco(deslocamentoProximoParametro); // para preencher o
															// endere�o de
															// retorno
			tabelaSimbolos.add(st);
		} else {
			if (st.isDeclarada() && declarando) {
				throw new ErroSemanticoException(
						"Declara��o (RI) duplicada de fun��o: " + st.getNome());
			} else {
				boolean erroTiposDiferentes = false;

				if ((tipoFuncaoSendoDeclarada != st.getTipo())
						|| (st.getTipoParametros().length != tiposParametros.length)) {
					erroTiposDiferentes = true;
				} else {

					for (int i = 0; i < st.getTipoParametros().length; i++) {

						if ((tipoFuncaoSendoDeclarada != st.getTipo())
								|| (st.getTipoParametros()[i] != tiposParametros[i])) {
							erroTiposDiferentes = true;
							break;
						}
					}
				}

				if (erroTiposDiferentes) {
					throw new ErroSemanticoException(
							"Assinatura da declara��o de fun��o difere de assinatura encontrada anteriormente...");
				}

				if (declarando) {
					st.setContexto(st.getNome());
					st.setDeclarada(true);
				}
			}
		}
	}

	private void alimentaPrototipoTabelaSimbolos(String nome,
			boolean declarando, int tiposParametros[]) {

		SimboloTabela st = buscaTabelaSimbolos(nome, SimboloTabela.T_PROTOTIPO);

		if (st == null) {
			st = new SimboloTabela(nome, tipoFuncaoSendoDeclarada,
					SimboloTabela.T_PROTOTIPO, declarando, tiposParametros);
			st.setContexto(st.getNome());

			// Setando endere�o onde se encontra o valor de retorno
			st.setEndereco(deslocamentoProximoParametro); // para preencher o
															// endere�o de
															// retorno
			tabelaSimbolos.add(st);
		} else {
			throw new ErroSemanticoException(
					"Declara��o duplicada de prot�tipo de fun��o: "
							+ st.getNome());
		}
	}

	private SimboloTabela buscaTabelaSimbolos(String chave, int classe) {

		Enumeration e = tabelaSimbolos.elements();
		while (e.hasMoreElements()) {
			SimboloTabela st = (SimboloTabela) e.nextElement();
			if (st.getNome().equalsIgnoreCase(chave)
					&& st.getClasse() == classe && st.isAtiva()) {
				return st;
			}
		}

		return null;
	}

	private SimboloTabela buscaTabelaSimbolos(String chave) {

		Enumeration e = tabelaSimbolos.elements();
		SimboloTabela st1 = null;
		SimboloTabela st2 = null;

		while (e.hasMoreElements()) {
			SimboloTabela st = (SimboloTabela) e.nextElement();

			if (st.getNome().equalsIgnoreCase(chave) && st.isAtiva()) {
				if (st1 == null) {
					st1 = st;
				} else {
					st2 = st;
				}
			}
		}
		if (st2 != null) {
			if (st2.getClasse() == SimboloTabela.T_LOCAL) {
				return st2;
			}
		}
		return st1;
	}

	/*
	 * Criada na inten��o de ser usada durante uma chamada de fun��o
	 */
	private SimboloTabela buscaTabelaSimbolos(String chave, String escopo) {

		Enumeration e = tabelaSimbolos.elements();
		SimboloTabela st1 = null;
		SimboloTabela st2 = null;

		while (e.hasMoreElements()) {
			SimboloTabela st = (SimboloTabela) e.nextElement();

			if (st.getNome().equalsIgnoreCase(chave)
					&& st.getContexto().equalsIgnoreCase(escopo)) {
				if (st1 == null) {
					st1 = st;
				} else {
					st2 = st;
				}
			}
		}
		if (st2 != null) {
			if (st2.getClasse() == SimboloTabela.T_LOCAL) {
				return st2;
			}
		}
		return st1;
	}

	private void desativaLocaisTabelaSimbolos(String nomeFuncao) {

		Enumeration e = tabelaSimbolos.elements();

		while (e.hasMoreElements()) {
			SimboloTabela st = (SimboloTabela) e.nextElement();
			;
			if (st.getContexto().equalsIgnoreCase(nomeFuncao)) {
				st.setAtiva(false);
			}
		}
	}

	public String getFonte() {
		return fonte.toString();
	}

	public void setNomeFonte(String n) {
		nomeFonte = n;
	}

	public String getNomeFonte() {
		return nomeFonte;
	}

	public int tamanhoTipo(int tipo) {
		switch (tipo) {
		case Lexico.T_INTEIRO:
			return 2;
		case Lexico.T_CARACTER:
			return 32;
		case Lexico.T_LOGICO:
			return 2;
		default:
			return 2;
		}
	}

	private void exibeMensagemSemantico(String mensagem) {

		Verto.getInstance().addMensagemSemantico(mensagem + "\n");
	}

	private void agregaRodape() {
		fonte.append(fonteRodape);
	}

	
	
	
	
	private void exibeMensagemTabelaSimbolos() {

		Vector<Vector<String>> itensTabelaSimbolos = new Vector<Vector<String>>();
        ;
        Vector<String> linhaTS = new Vector<String>();
        Vector<String> cabecalho = new Vector<String>();

        SimboloTabela st;

        cabecalho.add("Identificador");
        cabecalho.add("Endere�o");
        cabecalho.add("Tipo");
        cabecalho.add("Classe");
        cabecalho.add("Escopo");
        cabecalho.add("Parametros");
        cabecalho.add("Ativa");
        cabecalho.add("Tipo Identificador");

        Enumeration<SimboloTabela> i = tabelaSimbolos.elements();

        int j = 0;

        while (i.hasMoreElements()) {

            st = i.nextElement();

            linhaTS = new Vector<String>();
            linhaTS.add(st.getNome());
            linhaTS.add(new Integer(st.getEndereco()).toString());
            linhaTS.add(Lexico.getDsTipoDeclarado(st.getTipo()));
            if (st.isParametro()) {
                linhaTS.add("T_LOCAL (Param)");
            } else {
                linhaTS.add(SimboloTabela.getDsClasse(st.getClasse()));
            }
            linhaTS.add(st.getContexto());

            if (st.getTipoParametros() != null) {
                if (st.getTipoParametros().length > 0) {
                    StringBuffer sb = new StringBuffer();
                    sb.append("( ");
                    for (int k = 0; k < st.getTipoParametros().length; k++) {
                        sb.append((String) traduzAliasTipo(st
                                .getTipoParametros()[k]));
                        sb.append(" ");
                    }
                    sb.append(" )");
                    linhaTS.add(sb.toString());
                } else {
                    linhaTS.add("( )");
                }
            } else {
                linhaTS.add(" - ");
            }

            linhaTS.add(" " + (st.isAtiva() ? "Sim" : "N�o"));
            linhaTS.add(" " + (st.isConstante() ? "Constante" : st.isVetor() ? "Vetor" : st.getClasse() == SimboloTabela.T_FUNCAO ? "Fun��o": "Vari�vel" ));
           
            itensTabelaSimbolos.add(j, linhaTS);
            j++;
        }
        JTable table = new JTable(itensTabelaSimbolos, cabecalho);
        table.getColumnModel().getColumn(1).setMaxWidth(70);
        table.getColumnModel().getColumn(6).setMaxWidth(50);
        Verto.getInstance().setTableTabelaSimbolos(table);
	}

	private String traduzAliasTipo(int i) {
		switch (i) {
		case Lexico.T_INTEIRO:
			return "int";
		case Lexico.T_CARACTER:
			return "car";
		case Lexico.T_LOGICO:
			return "log";
		default:
			return "";
		}
	}

	private String proximoLabel() {
		labelAtual++;
		return "L" + labelAtual;
	}

	private String proximaCadeia() {
		cadeiaAtual++;
		return "C" + cadeiaAtual;
	}

	private String formataMacro(String label, String instrucao,
			String argumento, String comentario) {

		StringBuffer sb = new StringBuffer();

		if (label == null) {
			sb.append("\t");
		} else {
			sb.append(label);
			sb.append(":\n\t");
		}
		sb.append(instrucao);
		sb.append("\t");
		sb.append(argumento);
		sb.append("\t\t");

		if (sb.length() < 15) {
			sb.append("\t");
		}
		sb.append("; " + comentario + "\n");

		return sb.toString();
	}

}